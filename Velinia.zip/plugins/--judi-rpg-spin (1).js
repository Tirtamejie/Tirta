let handler = async (m, { conn, text, command, args, usedPrefix, DevMode }) => {
    try {
        let user = global.db.data.users[m.sender]
        let prevMoney = user.money // Simpan sisa money sebelum bermain

        if (!user.money) {
            conn.reply(m.chat, 'Kamu tidak memiliki money untuk bermain slotspin. Mulailah dengan .claim .weekly .monthly', m)
            return
        }

        let count = 0
        let bet = 1000
        let delay = 5000

        if (args.length >= 1 && args[0].toLowerCase() === 'all') {
            count = Math.floor(user.money / 100)
            bet = 100
        } else if (args.length >= 1) {
            count = Math.floor(args[0])
        }

        if (args.length >= 2) {
            bet = Math.max(100, Math.min(50000, Math.floor(args[1] / 100) * 100))
        }

        if (args.length >= 3) {
            delay = Math.max(3000, Math.min(50000, Math.floor(args[2])))
        }

        if (isNaN(count) || count <= 0) {
            conn.reply(m.chat, `Gunakan format *${usedPrefix}${command} [jumlahspin] [taruhan] [delay]* atau *${usedPrefix}${command} all*\nContoh: *${usedPrefix}${command} 10 4000 10000* atau *${usedPrefix}${command} all*`, m)
            return
        }

        if (bet % 100 !== 0) {
            conn.reply(m.chat, 'Taruhan harus berupa kelipatan 100, 1000, atau 10000.', m)
            return
        }

        if (bet * count > user.money) {
            conn.reply(m.chat, 'Maaf, money yang Anda miliki tidak cukup untuk memasang taruhan sebanyak itu.', m)
            return
        }

        if (count > 5000) {
            conn.reply(m.chat, 'Maksimal 5000 spin dalam satu perintah.', m)
            return
        }

        let symbols = ['🐠', '🐬', '🦊', '🐤', '🦅', '🦡', '🐱', '🐶']
        let totalPrize = 0
        let totalLoss = 0
        let currentSpinCount = 0
        let spinCost = bet
        let totalSpinCost = 0

        let { key } = await conn.sendMessage(m.chat, { text: '*🎰 Virtual Slot 🎰*\n\nMemulai dalam 10 detik...' })

        await new Promise(resolve => setTimeout(resolve, 10000)) // Delay 10 detik sebelum memulai

        for (let spin = 0; spin < count; spin++) {
            let result = []
            for (let i = 0; i < 8; i++) {
                result.push(pickRandom(symbols))
            }

            let multiplier = 0
            let symbolCount = result.reduce((acc, symbol) => {
                acc[symbol] = (acc[symbol] || 0) + 1
                return acc
            }, {})

            for (let c of Object.values(symbolCount)) {
                if (c >= 3) {
                    multiplier = Math.max(multiplier, c - 2)
                }
            }

            let winOrLose = multiplier > 0 ? `Menang! 🎉` : 'Kalah 😢'
            let winnings = bet * Math.pow(2, multiplier) * 1.5 // 180% kemenangan

            if (winOrLose === 'Kalah 😢') {
                let lossAmount = Math.floor(bet * 0.3) // 50% dari taruhan
                totalLoss += lossAmount
                totalSpinCost += spinCost
                let message = `
*🎰 Virtual Slot 🎰*

Putaran ke-${++currentSpinCount}/${count}
[${result.join(' ')}]

Kalah 😢 Money Anda Dikurangi: ${lossAmount}
Sisa money Anda: ${prevMoney + totalPrize - totalLoss - totalSpinCost}`
                await conn.sendMessage(m.chat, { text: message, edit: key })
            } else {
                totalPrize += winnings
                totalSpinCost += spinCost
                let message = `
*🎰 Virtual Slot 🎰*

Putaran ke-${++currentSpinCount}/${count}
[${result.join(' ')}]

Menang! 🎉 Money Anda Bertambah: ${winnings.toFixed(0)} 💰
Sisa money Anda: ${prevMoney + totalPrize - totalLoss - totalSpinCost}`
                await conn.sendMessage(m.chat, { text: message, edit: key })
            }

            if (spin % 25 === 24) {
                // Kenaikan Harga Spin
                spinCost += 250
            }

            if (spin < count - 1) {
                await new Promise(resolve => setTimeout(resolve, delay)) // Delay sesuai parameter
            }
        }

        // Hitung perubahan uang secara keseluruhan
        let moneyChange = totalPrize - totalLoss - totalSpinCost
        user.money = prevMoney + moneyChange

        let achievementMessage = ''
        if (totalPrize >= 100000) {
            // Achievement: Jackpot Pertama Kali
            achievementMessage = '\n\n🏆 Selamat! Anda mendapatkan Jackpot pertama kali!'
        }

        let message = `
*🎰 Virtual Slot 🎰*

Permainan Selesai!
Sisa money sebelum bermain: ${prevMoney.toLocaleString('id-ID')}
Total Kemenangan: ${totalPrize.toFixed(0)} 💰
Total Kekalahan: ${totalLoss}
Total Biaya Spin: ${totalSpinCost}
Perubahan Money: ${moneyChange > 0 ? '+' : ''}${moneyChange.toFixed(0)}
Sisa money Anda: ${user.money.toLocaleString('id-ID')}${achievementMessage}`

        await conn.sendMessage(m.chat, { text: message, edit: key })

    } catch (e) {
        console.error(e)
        conn.reply(m.chat, 'Terjadi kesalahan saat menjalankan perintah.', m)
        if (DevMode) {
            for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid)) {
                conn.sendMessage(jid, `Error di slot.js\n\nError: ${e}\n\n${e.stack}`)
            }
        }
    }
}

handler.help = ['slotspin 𝐁𝐚𝐫𝐮+𝐁𝐞𝐭𝐚']
handler.tags = ['game']
handler.command = /^(slotsp|slotspin)$/i

export default handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}