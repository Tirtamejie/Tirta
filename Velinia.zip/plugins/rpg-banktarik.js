const xpperlimit = 1;

let handler = async (m, { conn, command, args }) => {
  if (global.db.data.chats[m.chat].rpg == false && m.isGroup) {
    return conn.sendButton(m.chat, '❗ ᴏᴘᴛɪᴏɴs ʀᴘɢ ɢᴀᴍᴇ ᴅɪᴄʜᴀᴛ ɪɴɪ ʙᴇʟᴜᴍ ᴅɪɴʏᴀʟᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ', wm, null, [['ᴇɴᴀʙʟᴇ', '.on rpg']], m);
  }

  let user = global.db.data.users[m.sender];
  let all = command.replace(/^tarik/i, '').trim();
  let count;

  if (/all/i.test(all)) {
    count = Math.floor(user.bank / xpperlimit);
  } else {
    count = parseInt(all) || parseInt(args[0]) || 1; // Jika tidak ada input, default ke 1
  }

  count = Math.max(1, count); // Pastikan count minimal 1

  if (user.atm == 0) {
    return m.reply('kamu belum mempuyai kartu ATM !');
  }

  if (user.bank >= xpperlimit * count) {
    user.bank -= xpperlimit * count;
    user.money += count;
    conn.reply(m.chat, `Sukses menarik sebesar ${count} Money 💹`, m);
  } else {
    conn.reply(m.chat, `[❗] Uang dibank anda tidak mencukupi untuk ditarik sebesar ${count} money 💹`, m);
  }
};

handler.help = ['tarik 𝐅𝐢𝐱𝐞𝐝'];
handler.tags = ['rpg'];
handler.command = /^tarik([0-9]+)|tarik|tarikall$/i;
handler.group = true;
handler.rpg = true;

export default handler;