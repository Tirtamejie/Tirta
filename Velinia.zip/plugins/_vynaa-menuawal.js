import 'node-fetch';
const {
  proto,
  generateWAMessageFromContent,
  prepareWAMessageMedia
} = (await import("@adiwajshing/baileys"))["default"];

var handler = async (_0x154cf9, {
  conn: _0x3aa0f1,
  usedPrefix: _0x9f47d1,
  command: _0x28115d 
}) => {
  if (!_0x28115d) {
    throw `Use example ${_0x9f47d1}${_0x28115d} anu`;
  }
  _0x154cf9.reply('⌛Loading...');
  try {
    let message = generateWAMessageFromContent(_0x154cf9.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: "> ʜᴀɪ ɴᴀᴍᴀ ꜱᴀyᴀ ᴀᴅᴀʟᴀʜ ᴛɪɴᴢʙᴏᴛᴢ\n\n> ʙᴏᴛ ɪɴɪ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ sᴇʙᴀɢᴀɪ *ɢᴀᴍᴇ*, *ᴘᴇɴᴊᴀɢᴀ ɢʀᴜᴘ*, *ᴅᴀɴ ʟᴀɪɴɴʏᴀ*, ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴜᴀᴛ ᴋᴀᴍᴜ ʟᴇʙɪʜ ᴍᴜᴅᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀʟᴀɴɪ ʜᴀʀɪ-ʜᴀʀɪ\n\n> 𝐁𝐞𝐭𝐚 ꜰɪᴛᴜʀ ᴍᴀꜱɪʜ ᴅɪᴋᴇᴍʙᴀɴɢᴋᴀɴ ᴛᴇʀᴅᴀᴘᴀᴛ ᴇʀʀᴏʀ\n> 𝐅𝐢𝐧𝐚𝐥 ꜰɪᴛᴜʀ ᴛᴇʟᴀʜ ꜱᴇʟᴇꜱᴀɪ ᴅɪᴋᴇᴍʙᴀɴɢᴋᴀɴ\n> 𝐁𝐚𝐫𝐮 ꜰɪᴛᴜʀ ʙᴀʀᴜ\n> 𝐅𝐢𝐱𝐞𝐝 ꜰɪᴛᴜʀ ᴅɪᴘᴇʀʙᴀɪᴋɪ"
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: wm
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: true,
              ...(await prepareWAMessageMedia({
                image: { url: "https://files.catbox.moe/js0l8u.jpg" }
              }, { upload: _0x3aa0f1.waUploadToServer }))
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                { name: "quick_reply", buttonParamsJson: "{\"display_text\":\"Menulist\",\"id\":\".listmenu\"}" },
                { name: "quick_reply", buttonParamsJson: "{\"display_text\":\"Menuall\",\"id\":\".allmenu\"}" }
              ]
            })
          })
        }
      }
    }, { quoted: _0x154cf9 });
 
    return await _0x3aa0f1.relayMessage(_0x154cf9.chat, message.message, {});
  } catch (error) {
    _0x3aa0f1.sendFile(_0x154cf9.chat, 'error.mp3', 'anu.mp3', null, _0x154cf9, true, {
      type: "audioMessage",
      ptt: true
    });
  }
};

handler.help = ["menu"];
handler.tags = ["menu"];
handler.command = /^(menu|help)$/i;
handler.limit = false;
handler.register = true;

export default handler;