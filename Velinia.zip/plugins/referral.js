let handler = async (m, { conn, args }) => {
  if (args[0] && args[0].length === 6) {
    let referralCode = args[0].toUpperCase()
    let referrer = Object.keys(global.db.data.users).find(v => global.db.data.users[v].referrer === referralCode)
    if (referrer) {
      global.db.data.users[m.sender].referrer = referralCode
      conn.reply(m.chat, `Anda telah terdaftar sebagai referral dari @${referrer.split('@')[0]}`, m, { mentions: [referrer] })
    } else {
      conn.reply(m.chat, `Kode referral "${referralCode}" tidak valid.`, m)
    }
  } else {
    conn.reply(m.chat, `Contoh penggunaan: .referral ABCD12`, m)
  }
}

handler.help = ['referral <kode_referral>']
handler.tags = ['game']
handler.command = /^(referral)$/i

export default handler