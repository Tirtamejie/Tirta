const xpperlimit = 1

let handler = async (m, { conn, command, args }) => {
  let user = global.db.data.users[m.sender]
  let count = args[0] ? 
    /all/i.test(args[0]) ? Math.floor(user.money / xpperlimit) : 
    isNaN(parseInt(args[0])) ? 1 : parseInt(args[0])
  : 1
  
  count = Math.max(1, count)

  if (user.atm == 0) return m.reply('Kamu belum mempunyai kartu ATM')
  if (user.bank >= user.fullatm) return m.reply('Uang di ATM sudah penuh!')
  if (count > user.fullatm - user.bank) return m.reply('Jumlah yang ingin ditabung melebihi batas ATM')
  if (user.money < xpperlimit * count) return m.reply(`Uang anda tidak mencukupi untuk menabung ${count} money 💹`)

  user.money -= xpperlimit * count
  user.bank += count
  
  conn.reply(m.chat, `Sukses menabung sebesar ${count} Money 💹`, m)
}

handler.help = ['nabung 𝐅𝐢𝐱𝐞𝐝']
handler.tags = ['rpg']
handler.command = /^(nabung|atm)$/i
handler.rpg = true
handler.group = true

export default handler