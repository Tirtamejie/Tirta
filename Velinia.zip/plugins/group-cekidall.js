let handler = async (m, { conn }) => {
  let groups = await conn.groupFetchAllParticipating();
  let groupsId = Object.keys(groups);
  let text = `*Daftar ID Grup:*\n\n`;

  for (let id of groupsId) {
    let groupMetadata = await conn.groupMetadata(id);
    let { subject, creation, owner, participants, announce, restrict } = groupMetadata;
    let participantsCount = participants.length;
    let status = announce ? 'Pengumuman' : restrict ? 'Terbatas' : 'Bebas';

    text += `• ID: ${id}\n`;
    text += `• Nama: ${subject}\n`;
    text += `• Jumlah Anggota: ${participantsCount}\n`;
    text += `• Status: ${status}\n\n`;
  }

  await conn.reply(m.chat, text, m);
};

handler.help = ['cekidall 𝐁𝐞𝐭𝐚'];
handler.tags = ['group'];
handler.premium = true;
handler.command = /^(cekidall|idall)$/i;
handler.group = true;

export default handler;