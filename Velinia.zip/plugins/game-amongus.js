class GameSession {
	constructor(id, sMsg) {
		this.id = id;
		this.players = [];
		this.game = new AmongUsGame(sMsg);
	}
}

class AmongUsGame {
	constructor(sMsg) {
		this.sendMsg = sMsg;
		this.players = [];
		this.impostors = [];
		this.crewmates = [];
		this.deadPlayers = [];
		this.votingResults = {};
		this.taskProgress = {};
		this.sabotages = [];
		this.gameState = 'lobby';
		this.currentPlayerIndex = 0;
		this.discussionTimer = 60; // 1 menit
		this.voteTimer = 30; // 30 detik
		this.taskCompletionTimer = 300; // 5 menit
		this.playerColors = ['red', 'blue', 'green', 'yellow', 'pink', 'orange', 'purple', 'brown'];
		this.afkTimeout = 120; // 2 menit untuk deteksi AFK
		this.afkCheck = {}; // Menyimpan waktu terakhir aktivitas pemain
		this.botPlayers = []; // Menyimpan nama bot
		this.aiDifficulty = 'medium'; // Kesulitan AI: easy, medium, hard
	}

	initializeGame() {
		this.assignRoles();
		this.gameState = 'playing';
		this.startTaskCompletionTimer();
		this.startAfkCheck();
	}

	assignRoles() {
		const impostorCount = Math.max(1, Math.floor(this.players.length * 0.25));
		this.impostors = this.players.sort(() => Math.random() - 0.5).slice(0, impostorCount);
		this.crewmates = this.players.filter(player => !this.impostors.includes(player));
		for (const player of this.players) {
			this.taskProgress[player] = 0;
			this.afkCheck[player] = Date.now(); // Inisialisasi waktu aktivitas
		}
	}

	startTaskCompletionTimer() {
		this.taskCompletionTimer = setInterval(() => {
			for (const player of this.crewmates) {
				if (this.botPlayers.includes(player)) {
					this.performBotTask(player);
				} else {
					this.taskProgress[player]++;
					if (this.taskProgress[player] >= 5) {
						this.winCrewmates();
						return;
					}
				}
			}
		}, 60000); // 1 menit
	}

	startAfkCheck() {
		setInterval(() => {
			for (const player in this.afkCheck) {
				if (Date.now() - this.afkCheck[player] > this.afkTimeout * 1000) {
					this.sendMsg(`⚠️ *${player} dianggap AFK dan dikeluarkan dari permainan.*`);
					this.removePlayer(player);
				}
			}
		}, 10000); // Cek tiap 10 detik
	}

	reportDead(reporter, reported) {
		this.deadPlayers.push(reported);
		const message = `😱 *${reporter} menemukan mayat ${reported}!*`;
		this.sendMsg(message);
		this.startDiscussionTimer();
		this.afkCheck[reporter] = Date.now(); // Update waktu aktivitas
	}

	startDiscussionTimer() {
		this.gameState = 'discussion';
		this.discussionTimer = setInterval(() => {
			this.discussionTimer--;
			if (this.discussionTimer === 0) {
				this.startVoting();
			}
		}, 1000);
	}

	startVoting() {
		clearInterval(this.discussionTimer);
		this.gameState = 'voting';
		this.voteTimer = setInterval(() => {
			this.voteTimer--;
			if (this.voteTimer === 0) {
				this.tallyvotes();
			}
		}, 1000);
	}

	tallyvotes() {
		clearInterval(this.voteTimer);
		const voteCount = Object.values(this.votingResults).reduce((a, b) => a + b, 0);
		if (voteCount === 0) {
			this.sendMsg('*Tidak ada yang terpilih.*');
		} else {
			const mostVotedPlayer = Object.keys(this.votingResults).reduce((a, b) => this.votingResults[a] > this.votingResults[b] ? a : b);
			if (this.impostors.includes(mostVotedPlayer)) {
				this.sendMsg(`*${mostVotedPlayer} adalah Impostor!* Crewmate menang!`);
				this.winCrewmates();
			} else {
				this.sendMsg(`*${mostVotedPlayer} terpilih.* Impostor menang!`);
				this.winImpostors();
			}
		}
		this.resetVoting();
	}

	resetVoting() {
		this.votingResults = {};
		this.gameState = 'playing';
	}

	winCrewmates() {
		this.sendMsg('*Crewmate menang!*');
		this.resetGame();
	}

	winImpostors() {
		this.sendMsg('*Impostor menang!*');
		this.resetGame();
	}

	resetGame() {
		clearInterval(this.taskCompletionTimer);
		this.players = [];
		this.impostors = [];
		this.crewmates = [];
		this.deadPlayers = [];
		this.votingResults = {};
		this.taskProgress = {};
		this.sabotages = [];
		this.gameState = 'lobby';
		this.currentPlayerIndex = 0;
		this.afkCheck = {};
	}

	performBotTask(bot) {
		// Logic AI di sini tergantung kesulitan
		let taskCompletionRate = this.aiDifficulty === 'easy' ? 0.1 : this.aiDifficulty === 'medium' ? 0.5 : 0.9;
		if (Math.random() < taskCompletionRate) {
			this.taskProgress[bot]++;
			if (this.taskProgress[bot] >= 5) {
				this.winCrewmates();
			}
		}
	}

	addPlayer(player, isBot = false) {
		if (this.players.length < 10 && !this.players.includes(player) && player !== '') {
			this.players.push(player);
			this.taskProgress[player] = 0;
			this.afkCheck[player] = Date.now();
			if (isBot) {
				this.botPlayers.push(player);
			}
			return true;
		} else {
			return false;
		}
	}

	removePlayer(player) {
		this.players = this.players.filter(p => p !== player);
		this.crewmates = this.crewmates.filter(p => p !== player);
		this.impostors = this.impostors.filter(p => p !== player);
		this.deadPlayers = this.deadPlayers.filter(p => p !== player);
		delete this.taskProgress[player];
		delete this.afkCheck[player];
		this.botPlayers = this.botPlayers.filter(p => p !== player);
	}

	startGame(m, players) {
		this.players = players;
		this.initializeGame();
		this.sendMsg(`🚀 *Among Us dimulai!* \n\n${players.join(', ')} siap untuk memulai permainan.`);
	}

	reportSabotage(reporter, sabotage) {
		this.sabotages.push(sabotage);
		const message = `🔧 *${reporter} melaporkan adanya sabotase: ${sabotage}!*`;
		this.sendMsg(message);
		this.afkCheck[reporter] = Date.now(); // Update waktu aktivitas
		// Lakukan tindakan untuk mengatasi sabotase
	}

	vote(voter, votedPlayer) {
		if (this.gameState === 'voting') {
			this.votingResults[votedPlayer] = (this.votingResults[votedPlayer] || 0) + 1;
			this.sendMsg(`*${voter} memilih ${votedPlayer}.*`);
			this.afkCheck[voter] = Date.now(); // Update waktu aktivitas
		} else {
			this.sendMsg('*Tidak ada sesi voting yang sedang berlangsung.*');
		}
	}
}

const handler = async (m, {
	conn,
	args,
	usedPrefix,
	command
}) => {
	conn.among_us = conn.among_us || {};
	const sessions = conn.among_us_ = conn.among_us_ || {};
	const sessionId = m.chat;
	const session = sessions[sessionId] || (sessions[sessionId] = new GameSession(sessionId, conn));
	const game = session.game;
	const {
		state
	} = conn.among_us[m.chat] || {
		state: false
	};

	switch (args[0]) {
		case 'join':
			if (state) return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat bergabung.');
			const playerName = m.sender;
			const joinSuccess = game.addPlayer(playerName);
			joinSuccess ? m.reply(`👋 *${playerName} bergabung ke dalam permainan.*`) : m.reply('*Anda sudah bergabung atau permainan sudah penuh.* Tidak dapat bergabung.');
			break;

		case 'start':
			if (state) return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat memulai ulang.');
			conn.among_us[m.chat] = {
				...conn.among_us[m.chat],
				state: true
			};
			if (game.players.length >= 4) {
				game.startGame(m, game.players);
			} else {
				await m.reply('👥 *Tidak cukup pemain untuk memulai permainan.* Diperlukan minimal 4 pemain.');
			}
			break;

		case 'report':
			if (!state) return m.reply('🛑 *Permainan belum dimulai.* Ketik "!among start" untuk memulai.');
			if (game.gameState === 'playing') {
				const [reported] = args.slice(1);
				if (game.deadPlayers.includes(reported)) {
					m.reply(`*${reported} sudah mati.*`);
				} else {
					game.reportDead(m.sender, reported);
				}
			} else {
				m.reply(`*Tidak ada yang bisa dilaporkan saat ini.* Permainan sedang dalam fase ${game.gameState}.`);
			}
			break;

		case 'vote':
			if (!state) return m.reply('🛑 *Permainan belum dimulai.* Ketik "!among start" untuk memulai.');
			if (game.gameState === 'voting') {
				const [votedPlayer] = args.slice(1);
				game.vote(m.sender, votedPlayer);
			} else {
				m.reply(`*Tidak ada sesi voting yang sedang berlangsung.* Permainan sedang dalam fase ${game.gameState}.`);
			}
			break;

		case 'sabotage':
			if (!state) return m.reply('🛑 *Permainan belum dimulai.* Ketik "!among start" untuk memulai.');
			if (game.gameState === 'playing') {
				const [sabotage] = args.slice(1);
				game.reportSabotage(m.sender, sabotage);
			} else {
				m.reply(`*Tidak ada yang bisa disabotase saat ini.* Permainan sedang dalam fase ${game.gameState}.`);
			}
			break;

		case 'reset':
			conn.among_us[m.chat] = {
				...conn.among_us[m.chat],
				state: false
			};
			session.game.resetGame();
			delete sessions[sessionId];
			await m.reply('🔄 *Sesi permainan direset.*');
			break;

		case 'help':
			await m.reply(`🚀 *Among Us* 🚀

Among Us adalah permainan multiplayer online di mana beberapa pemain ditunjuk sebagai Impostor, sementara yang lain menjadi Crewmate. Tujuan Impostor adalah membunuh semua Crewmate tanpa ketahuan, sementara Crewmate harus menyelesaikan tugas-tugas dan mengidentifikasi Impostor.

*🎮 Cara Bermain:*
1. Permainan dimainkan oleh 4-10 pemain.
2. Beberapa pemain akan ditunjuk sebagai Impostor, sementara yang lain menjadi Crewmate.
3. Impostor berusaha membunuh Crewmate tanpa ketahuan.
4. Crewmate harus menyelesaikan tugas-tugas di seluruh peta dan mengidentifikasi Impostor.
5. Jika ada yang mati, pemain lain dapat melaporkan mayat dan memulai sesi diskusi.
6. Selama sesi diskusi, pemain dapat memilih siapa yang akan di-vote.
7. Jika Impostor terpilih, Crewmate menang. Jika tidak, Impostor menang.

*👥 Jumlah Pemain:*
- Among Us dapat dimainkan oleh 4 hingga 10 pemain.

*🛠️ Perintah Permainan:*
• ${usedPrefix + command} join  : Bergabung ke dalam permainan
• ${usedPrefix + command} start : Memulai permainan
• ${usedPrefix + command} report [player] : Melaporkan pemain yang ditemukan mati
• ${usedPrefix + command} vote [player] : Memilih pemain yang dicurigai sebagai Impostor
• ${usedPrefix + command} sabotage [sabotage] : Melaporkan adanya sabotase
• ${usedPrefix + command} reset : Mengatur ulang sesi permainan

*💡 Tips Bermain:*
- Sebagai Impostor, bersikaplah natural dan hindari kecurigaan.
- Sebagai Crewmate, perhatikan perilaku pemain lain dan laporkan hal yang mencurigakan.
- Diskusikan dan gunakan suara mayoritas untuk memilih Impostor.
- Bekerja sama dengan tim untuk menyelesaikan tugas-tugas.
- Ingat, kecerdikan dan strategi adalah kunci dalam memenangkan Among Us!

Selamat bermain dan semoga keberuntungan berpihak pada Anda! 🍀`);
			break;

		default:
			m.reply(`❓ *Perintah tidak valid.* Gunakan ${usedPrefix + command} help untuk melihat daftar perintah.`);
	}
};

handler.help = ['among 𝐁𝐚𝐫𝐮+𝐁𝐞𝐭𝐚'];
handler.tags = ['game'];
handler.command = /^(among(us)?)$/i;

export default handler;