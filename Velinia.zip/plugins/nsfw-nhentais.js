import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text) return m.reply(`Masukan Judul Yang Ingin Dicari!\n\nContoh :\n${usedPrefix + command} Gotoubun`)
    m.reply(wait)
    try {
        let api = await fetch(API('lol', '/api/nhentaisearch', { query: text }, 'apikey'))
        let res = await api.json()
        if (!res.result || res.result.length === 0) return m.reply('Tidak ditemukan hasil yang cocok.')
        let caption = ''
        for (let i = 0; i < res.result.length; i++) {
            caption += `
_*${i + 1}. ${res.result[i].title_native}*_
❃ Link : https://nhentai.net/${res.result[i].id}
❃ Page : ${res.result[i].page}
❃ Code : ${res.result[i].id}
`.trim() + '\n\n'
        }
        m.reply(caption)
    } catch (e) {
        console.error(e)
        m.reply('Terjadi kesalahan saat mengambil data.')
    }
}

handler.help = ['nhentais <query>']
handler.tags = ['nsfw', 'menuprem']
handler.command = /^(nhentai(s|search))$/i
handler.premium = true
handler.nsfw = true
handler.age = 18

export default handler