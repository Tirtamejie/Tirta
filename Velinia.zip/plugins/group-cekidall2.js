let handler = async (m, { conn, groupMetadata }) => {
  let groups = await conn.groupFetchAllParticipating();
  let text = 'List of Groups:\n\n';
  for (let group of groups) {
    text += `* Group ID: ${group.id}\n`;
    text += `* Group Name: ${group.subject}\n`;
    text += `* Participants: ${group.participants.length}\n`;
    text += `* Group Description: ${group.desc}\n`;
    text += `* Group Open: ${group.announcement}\n`;
    text += `* Group Archived: ${group.archive}\n`;
    text += `* Group Locked: ${group.locked}\n`;
    text += `* Group Invite Link: ${group.inviteLink}\n`;
    text += `\n`;
  }
  conn.reply(m.chat, text, m);
};
handler.help = ['cekidall2'];
handler.tags = ['group'];
handler.premium = true;
handler.command = /^(cekidall2)$/i;

handler.group = true;

export default handler;