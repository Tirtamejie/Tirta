let handler = async (m, { conn, command, text, args }) => {
    if (!text) throw 'Format salah!\n\nTambah money: addmoney <tag orang> <jumlah money>\nKurangi money: removemoney <tag orang> <jumlah money>'
    let [who, ...valueWords] = text.split(' ')
    if (!who) throw 'Tag orang yang akan diubah moneynya!'
    let value = valueWords.join(' ')
    if (!value) throw 'Jumlah harus diisi!'
    value = parseInt(value)
    if (isNaN(value)) throw 'Jumlah harus angka!'
    let user = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : (who.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
    let users = global.db.data.users
    if (!users[user]) users[user] = { money: 0, level: 1, diamond: 0 } // Ensure user object exists
    
    switch (command.toLowerCase()) {
        case 'addmoney':
            users[user].money += value
            conn.reply(m.chat, `Berhasil menambahkan ${value} money untuk @${user.split('@')[0]}!`, m, { mentions: [user] })
            break
        case 'removemoney':
        case 'remmoney':
            if (value > users[user].money) {
                users[user].money = 0
                conn.reply(m.chat, `Berhasil mengurangi money untuk @${user.split('@')[0]}. Money kini menjadi 0!`, m, { mentions: [user] })
            } else {
                users[user].money -= value
                conn.reply(m.chat, `Berhasil mengurangi ${value} money untuk @${user.split('@')[0]}!`, m, { mentions: [user] })
            }
            break
        case 'addlevel':
            users[user].level += value
            conn.reply(m.chat, `Berhasil menambahkan ${value} level untuk @${user.split('@')[0]}!`, m, { mentions: [user] })
            break
        case 'adddiamond':
            users[user].diamond += value
            conn.reply(m.chat, `Berhasil menambahkan ${value} diamond untuk @${user.split('@')[0]}!`, m, { mentions: [user] })
            break
        default:
            throw 'Command tidak valid!'
    }
}

handler.help = ['addmoney', 'removemoney', 'addlevel', 'adddiamond']
handler.tags = ['owner']
handler.command = /^(add|remove|rem)money$|^addlevel$|^adddiamond$/i
handler.rowner = true

export default handler