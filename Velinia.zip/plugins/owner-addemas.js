import fs from "fs"

let handler = async (m, { conn, args, command }) => {
    if (!m.mentionedJid) return m.reply('Tag pengguna yang ingin dimodifikasi emasnya.')
    
    let mentionedJid = m.mentionedJid[0]
    if (!(mentionedJid in global.db.data.users)) return m.reply(`Pengguna ${mentionedJid} tidak ditemukan dalam database`)
    
    let user = global.db.data.users[mentionedJid]
    
    switch (command) {
        case 'addemas':
            if (isNaN(args[1])) return m.reply('Jumlah yang Anda masukkan bukan angka.')
            
            let amount = parseFloat(args[1])
            user.emas = (user.emas || 0) + amount
            
            const addCaption = `
▧「 *TAMBAH EMAS* 」
│ 👤 Nama: ${user.registered ? user.name : conn.getName(m.sender)}
│ 💰 Emas: ${user.emas.toFixed(2)} gram
└────···
`.trim()

            await conn.adReply(m.chat, addCaption, '', '', fs.readFileSync('./media/thumbnail.jpg'), '', m)
            break
        
        case 'resetemas':
            user.emas = 0

            const resetCaption = `
▧「 *RESET EMAS* 」
│ 👤 Nama: ${user.registered ? user.name : conn.getName(m.sender)}
│ 💰 Emas: ${user.emas.toFixed(2)} gram
└────···
`.trim()

            await conn.adReply(m.chat, resetCaption, '', '', fs.readFileSync('./media/thumbnail.jpg'), '', m)
            break
        
        default:
            return m.reply('Perintah tidak dikenal.')
    }

    global.db.data.users[mentionedJid] = user
    fs.writeFileSync('./database.json', JSON.stringify(global.db))
}

handler.help = ['addemas @taguser jumlah', 'resetemas @taguser']
handler.tags = ['rpg']
handler.command = /^(addemas|resetemas)$/i

handler.register = true
handler.group = true
handler.rpg = true
handler.owner = true;

export default handler