const delay = time => new Promise(res => setTimeout(res, time));

let handler = async (m, { conn, isOwner }) => {
    await delay(1000);
    let text;
    let fdoc = { key: { remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net' }, message: { documentMessage: { title: 'TinzBotz' } } };
    if (isOwner) {
        text = `Eh ada sayangku, cintaku, hidupku😙 @${m.sender.split('@')[0]}`;
    } else {
        text = `Halo @${m.sender.split('@')[0]}, ada yang bisa aku bantu?`;
    }
    try {
        await conn.sendMessage(m.chat, { text: text, mentions: [m.sender] }, { quoted: fdoc });
    } catch (error) {
        console.error(error);
        await conn.sendMessage(m.chat, 'Terjadi kesalahan saat mengirim pesan.', 'conversation', { quoted: m });
    }
};

handler.customPrefix = /^(bottest|bot|tirtamejie|bott|sayang)$/i;
handler.command = new RegExp();
export default handler;