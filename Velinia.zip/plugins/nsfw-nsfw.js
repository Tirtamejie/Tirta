import fetch from 'node-fetch'
import axios from 'axios'

let handler = async (m, { conn, usedPrefix, command }) => {
  if (!global.db.data.chats[m.chat].nsfw) throw `🚫 Grup tidak mendukung konten nsfw \n\nUntuk mengaktifkan tipe \n*${usedPrefix}enable* nsfw`
  let user = global.db.data.users[m.sender].age
  if (user < 17) throw m.reply(`❎ Anda masih di bawah umur! Kembalilah saat Anda berusia di atas 18 tahun`)

  await m.react('⏱️')
  let type = (command).toLowerCase()

  switch (type) {
    case 'ass':
    case 'culos':
      let as = await conn.getFile(global.API('fgmods', '/api/nsfw/ass', {}, 'apikey'))
      await conn.sendFile(m.chat, as.data, 'img.jpg', `✅ Random ${command}`, m)
      await m.react('✅')
      break

    case 'boobies':
    case 'boobs':
      let xb = await conn.getFile(global.API('fgmods', '/api/nsfw/boobs', {}, 'apikey'))
      await conn.sendFile(m.chat, xb.data, 'img.jpg', `✅ Random ${command}`, m)
      await m.react('✅')
      break

    case 'lesbians':
    case 'lesbian':
      let les = await conn.getFile(global.API('fgmods', '/api/nsfw/lesbian', {}, 'apikey'))
      await conn.sendFile(m.chat, les.data, 'img.jpg', `✅ Random ${command}`, m)
      await m.react('✅')
      break

    case 'pack':
      let img = await conn.getFile(global.API('fgmods', '/api/nsfw/cosplay', {}, 'apikey'))
      await conn.sendFile(m.chat, img.data, 'img.jpg', `✅ Resultado 🤭`, m)
      await m.react('✅')
      break

    default:
      break
  }
}

handler.help = ['ass', 'boobs', 'lesbian', 'pussy', 'pack']
handler.tags = ['nsfw']
handler.command = /^(ass|culos|boobs|boobies|lesbian|lesbians|pack)$/i
handler.premium = true
handler.register = true
handler.group = true

export default handler