const handler = async (m, { conn, usedPrefix, args, command }) => {
    // Inisialisasi objek panjatPinangRooms jika belum ada
    conn.panjatPinangRooms = conn.panjatPinangRooms || {};

    // Daftar hadiah
    const rewards = [
        "Smartphone", "Laptop", "Headphone", "Smartwatch", "Tablet",
        "Kamera", "Power Bank", "Earbuds", "Speaker Bluetooth", "Gadget Gaming"
    ];

    // Daftar pertanyaan
    const questions = [
        { question: "Apakah benar penemu lampu Thomas Alva Edison?", answer: "benar" },
        { question: "Apakah benar air mendidih pada suhu 100 derajat Celcius?", answer: "benar" },
        { question: "Apakah benar bumi itu datar?", answer: "salah" },
        { question: "Apakah benar Jakarta adalah ibu kota Indonesia?", answer: "benar" },
        { question: "Apakah benar kucing adalah mamalia?", answer: "benar" }
    ];

    // Kelas BotPlayer
    class BotPlayer {
        constructor(name) {
            this.name = name;
            this.isBot = true;
        }

        async answerChallenge() {
            return Math.random() < 0.5 ? 'benar' : 'salah';
        }
    }

    // Handle perintah tanpa argumen atau dengan argumen 'help'
    if (!args[0] || args[0] === "help") {
        const message = `*❏ PANJAT PINANG🎉*

• ${usedPrefix}pp create (buat room) 
• ${usedPrefix}pp join (player join, taruhan 1000000)
• ${usedPrefix}pp player (daftar pemain yang bergabung)
• ${usedPrefix}pp mulai (mulai game)
• ${usedPrefix}pp delete (hapus sesi room game)
• ${usedPrefix}pp tambahbot (tambahkan bot pemain)
• ${usedPrefix}pp jawab (jawaban Anda)

Minimal 2 pemain untuk memulai game.

Taruhan: 1000000
Hadiah: Barang-barang menarik seperti Smartphone, Laptop, dan lainnya.`;
        await conn.sendMessage(m.chat, {
            text: message,
            contextInfo: {
                externalAdReply: {
                    title: wm,
                    body: 'Ayo ikut dan menangkan hadiahnya!',
                    thumbnailUrl: 'https://telegra.ph/file/d3366813c259e145c24c1.jpg',
                    sourceUrl: link.web,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        });
        return;
    }

    // Logika berdasarkan argumen pertama
    switch (args[0].toLowerCase()) {
        case 'create':
            // Logika untuk membuat room
            if (conn.panjatPinangRooms[m.chat]) {
                return m.reply('Room sudah ada.');
            }
            conn.panjatPinangRooms[m.chat] = {
                players: [],
                bots: [],
                gameStarted: false,
                bank: 0 // Inisialisasi bank untuk taruhan
            };
            m.reply('Room berhasil dibuat. Pemain sekarang bisa bergabung.');
            break;

        case 'join':
            // Logika agar pemain bergabung ke room
            if (!conn.panjatPinangRooms[m.chat]) {
                return m.reply('Belum ada room yang dibuat. Gunakan .pp create untuk membuat room.');
            }
            if (conn.panjatPinangRooms[m.chat].gameStarted) {
                return m.reply('Game sudah dimulai. Tidak bisa bergabung sekarang.');
            }
            if (conn.panjatPinangRooms[m.chat].players.find(p => p.id === m.sender)) {
                return m.reply('Anda sudah bergabung di room.');
            }
            const playerName = m.pushName || conn.getName(m.sender);
            conn.panjatPinangRooms[m.chat].players.push({ id: m.sender, name: playerName });
            conn.panjatPinangRooms[m.chat].bank += 1000000; // Tambahkan taruhan ke bank
            m.reply(`Anda berhasil bergabung di room. Anda telah memasang taruhan sebesar 1000000. Total taruhan: ${conn.panjatPinangRooms[m.chat].bank}`);
            break;

        case 'tambahbot':
            // Logika untuk menambahkan bot pemain
            if (!conn.panjatPinangRooms[m.chat]) {
                return m.reply('Belum ada room yang dibuat. Gunakan .pp create untuk membuat room.');
            }
            if (conn.panjatPinangRooms[m.chat].bots.length >= 2) {
                return m.reply('Maksimal 2 bot pemain.');
            }
            const botName = `Bot${conn.panjatPinangRooms[m.chat].bots.length + 1}`;
            const botPlayer = new BotPlayer(botName);
            conn.panjatPinangRooms[m.chat].bots.push(botPlayer);
            conn.panjatPinangRooms[m.chat].players.push(botPlayer);
            conn.panjatPinangRooms[m.chat].bank += 1000000; // Tambahkan taruhan bot ke bank
            m.reply(`Bot ${botName} berhasil ditambahkan ke room.`);
            break;

        case 'player':
            // Logika untuk daftar pemain yang bergabung
            if (!conn.panjatPinangRooms[m.chat]) {
                return m.reply('Belum ada room yang dibuat. Gunakan .pp create untuk membuat room.');
            }
            const players = conn.panjatPinangRooms[m.chat].players;
            m.reply(`Pemain yang bergabung: \n${players.map(p => `${p.name} (${p.isBot ? 'Bot' : 'Player'})`).join('\n')}`);
            break;

        case 'mulai':
            // Logika untuk memulai game
            if (!conn.panjatPinangRooms[m.chat]) {
                return m.reply('Belum ada room yang dibuat. Gunakan .pp create untuk membuat room.');
            }
            if (conn.panjatPinangRooms[m.chat].players.length < 2) {
                return m.reply('Minimal 2 pemain untuk memulai game.');
            }
            conn.panjatPinangRooms[m.chat].gameStarted = true;
            m.reply('Game dimulai! Setiap pemain akan mendapatkan hadiah barang secara acak setelah menjawab tantangan.');

            // Jeda 10 detik untuk tantangan dan pemberian hadiah
            setTimeout(async () => {
                for (const player of conn.panjatPinangRooms[m.chat].players) {
                    const questionIndex = Math.floor(Math.random() * questions.length);
                    const challenge = questions[questionIndex].question;
                    const correctAnswer = questions[questionIndex].answer;
                    conn.panjatPinangRooms[m.chat].currentChallenge = { question: challenge, answer: correctAnswer };
                    let answer;
                    if (player.isBot) {
                        answer = await player.answerChallenge();
                    } else {
                        await m.reply(`@${player.name}, tantangan untukmu: "${challenge}". Jawab dengan "${usedPrefix}pp jawab benar/salah".`, null, { mentions: [player.name] });
                        // Tunggu jawaban dari pemain
                        const response = await conn.awaitMessage(m.from, 60000);
                        if (response && response.message) {
                            answer = response.message.text.toLowerCase();
                        } else {
                            answer = 'salah'; // Jika tidak menjawab dalam waktu
                        }
                    }
                    // Cek jawaban
                    if (answer === correctAnswer) {
                        const reward = rewards[Math.floor(Math.random() * rewards.length)];
                        m.reply(`Selamat ${player.name}! Anda mendapatkan hadiah berupa ${reward}.`);
                    } else {
                        m.reply(`Maaf ${player.name}, jawaban Anda salah. Anda tidak mendapatkan hadiah.`);
                    }
                }

                // Bersihkan room setelah permainan selesai
                delete conn.panjatPinangRooms[m.chat];
            }, 10000); // Jeda 10 detik untuk tantangan dan pemberian hadiah
            break;

        case 'delete':
            // Logika untuk menghapus room
            if (!conn.panjatPinangRooms[m.chat]) {
                return m.reply('Belum ada room yang dibuat.');
            }
            delete conn.panjatPinangRooms[m.chat];
            m.reply('Room telah dihapus.');
            break;

        case 'jawab':
            if (!conn.panjatPinangRooms[m.chat]) {
                return m.reply('Belum ada room yang dibuat.');
            }
            const player = conn.panjatPinangRooms[m.chat].players.find(p => p.id === m.sender);
            if (!player) {
                return m.reply('Anda belum bergabung di room.');
            }
            if (!conn.panjatPinangRooms[m.chat].gameStarted) {
                return m.reply('Game belum dimulai.');
            }
            if (!conn.panjatPinangRooms[m.chat].currentChallenge) {
                return m.reply('Tidak ada tantangan yang sedang berlangsung.');
            }
            const { question, answer } = conn.panjatPinangRooms[m.chat].currentChallenge;
            if (args[1] === answer) {
                const reward = rewards[Math.floor(Math.random() * rewards.length)];
                m.reply(`Selamat! Jawaban Anda benar. Anda mendapatkan hadiah berupa ${reward}.`);
            } else {
                m.reply('Maaf, jawaban Anda salah.');
            }
            break;

        default:
            m.reply('Perintah tidak dikenal. Gunakan .pp help untuk melihat daftar perintah.');
    }
};

handler.help = ['panjatpinang 𝐁𝐞𝐭𝐚']
handler.tags = ['game']
handler.command = /^(panjatpinang|pp)$/i
handler.group = true
export default handler;