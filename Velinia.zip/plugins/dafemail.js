import { createHash } from 'crypto'
import fetch from 'node-fetch'
import nodemailer from 'nodemailer'

let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i
let handler = async function (m, { conn, text, usedPrefix, command }) {
    // Nama
    let namae = conn.getName(m.sender)
    // Database 
    let user = global.db.data.users[m.sender]
    // Profil
    const pp = await conn.profilePictureUrl(m.sender, "image").catch((_) => "https://telegra.ph/file/ee60957d56941b8fdd221.jpg")

    // Memeriksa apakah pengguna sudah terdaftar
    if (user.registered === true) throw `Anda sudah terdaftar dalam Database, Apakah Anda ingin mendaftar ulang? */unreg*`

    // Mendapatkan email dari pesan
    const [_, email, otp] = text.match(/(\S+)\/(\S+)/) || []
    if (!email || !otp) return m.reply(`Format yang benar adalah: .dafemail email/otp`)

    // Membuat OTP
    let otpNum = Math.floor(10000 + Math.random() * 90000)

    try {
        // Menyimpan OTP dan email ke data pengguna
        user.otp = otpNum.toString()
        user.otpExpiry = Date.now() + 5 * 60 * 1000 // OTP berlaku selama 5 menit
        user.email = email

        // Mengirim OTP ke email
        await sendOTPEmail(email, otpNum)

        // Pesan verifikasi
        await conn.sendMessage(m.sender, { text: `
• Silakan masukkan OTP yang telah dikirim ke email Anda dengan cara ketik *.veremail* <otp>
• Kode OTP berlaku selama 5 menit
• Jangan berikan kode atau menyebarkan kode OTP kepada orang asing` })
    } catch (error) {
        console.error(error)
        await m.reply('Terjadi kesalahan saat mengirim OTP ke email Anda. Silakan coba lagi nanti.')
    }
}

// Fungsi untuk mengirim OTP melalui email
async function sendOTPEmail(email, otp) {
    // Konfigurasi nodemailer
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'tinzbot@gmail.com',
            pass: 'tirta123654'
        }
    });

    // Opsi email
    const mailOptions = {
        from: 'your-email@gmail.com',
        to: email,
        subject: 'OTP for Registration',
        text: `Your OTP is: ${otp}`
    };

    // Mengirim email
    await transporter.sendMail(mailOptions);
}

handler.help = ['dafemail 𝐁𝐚𝐫𝐮+𝐁𝐞𝐭𝐚'];
handler.tags = ['xp'];
handler.command = /^dafemail$/i;
handler.private = true;

export default handler