class GameSession {
    constructor(id, conn) {
        this.id = id;
        this.players = [];
        this.game = new PachirosuroGame(conn);
    }
}

class BotPlayer {
    constructor(name) {
        this.name = name;
        this.isBot = true;
        this.money = 1000;
    }

    makeDecision() {
        return 'spin';
    }
}

class PachirosuroGame {
    constructor(conn) {
        this.conn = conn;
        this.reelSymbols = ['🍒', '🍋', '🍊', '🍌', '7️⃣', '💎'];
        this.reelPositions = [0, 0, 0];
        this.jackpot = 10000;
        this.players = [];
        this.botPlayers = [];
        this.currentPlayerIndex = 0;
        this.gameState = 'lobby';
        this.roundCount = 0;
        this.maxRounds = 10;
        this.spinTimeout = null;
        this.previousSpinMessage = null;
    }

    spin(player) {
        if (this.gameState !== 'playing') {
            return 'Permainan belum dimulai.';
        }
        if (player.money < 10) {
            return `${player.name} tidak memiliki saldo yang cukup.`;
        }
        player.money -= 10;
        this.reelPositions = this.reelPositions.map(() => Math.floor(Math.random() * this.reelSymbols.length));
        const symbols = this.reelPositions.map(pos => this.reelSymbols[pos]);
        const winnings = this.calculateWinnings(symbols);
        player.money += winnings;
        let message = `${player.name} memutar slot: ${symbols.join(' | ')} \nKemenangan: ${winnings} money`;

        // Hapus pesan spin sebelumnya
        if (this.previousSpinMessage) {
            await this.conn.deleteMessage(m.chat, this.previousSpinMessage.key);
        }

        // Kirim pesan spin baru
        this.previousSpinMessage = await this.conn.reply(m.chat, message);
        return message;
    }

    calculateWinnings(symbols) {
        let winnings = 0;
        if (symbols[0] === symbols[1] && symbols[1] === symbols[2]) {
            if (symbols[0] === '7️⃣') {
                winnings = this.jackpot;
            } else {
                winnings = 100;
            }
        } else if (symbols[0] === symbols[1] || symbols[1] === symbols[2] || symbols[0] === symbols[2]) {
            winnings = 20;
        }
        return winnings;
    }

    addPlayer(player) {
        if (this.players.length < 4 && !this.players.some(p => p.name === player) && player !== '') {
            const newPlayer = { name: player, money: 1000, isBot: false };
            this.players.push(newPlayer);
            return true;
        } else {
            return false;
        }
    }

    addBotPlayer() {
        if (this.players.length < 4) {
            const botName = `Bot${this.botPlayers.length + 1}`;
            const botPlayer = new BotPlayer(botName);
            this.botPlayers.push(botPlayer);
            this.players.push(botPlayer);
            return true;
        }
        return false;
    }

    async startGame(m) {
        while (this.players.length < 4) {
            this.addBotPlayer();
        }
        this.initializeGame();
        const playerNames = this.players.map(p => p.isBot ? `🤖 ${p.name}` : p.name).join(', ');
        await this.conn.reply(m.chat, `🎰 *Pachirosuro dimulai!* \n\n${playerNames} siap untuk memulai permainan.`);
        await this.playRound(m);
    }

    async playRound(m) {
        if (this.gameState !== 'playing' || this.roundCount >= this.maxRounds) {
            await this.endGame(m);
            return;
        }

        const currentPlayer = this.players[this.currentPlayerIndex];

        if (currentPlayer.isBot) {
            const spinResult = await this.spinBot(currentPlayer);
            await this.conn.reply(m.chat, spinResult);
            this.nextPlayer();
            await this.playRound(m);
        } else {
            await this.conn.reply(m.chat, `🎰 Giliran ${currentPlayer.name}. Ketik '!pachirosuro spin' untuk memutar slot.`);
            this.startSpinTimeout(m, currentPlayer);
        }
    }

    async spinBot(player) {
        const spinResult = this.spin(player);
        await new Promise(resolve => setTimeout(resolve, 3000)); // Delay 3 detik
        return spinResult;
    }

    startSpinTimeout(m, currentPlayer) {
        if (this.spinTimeout) {
            clearTimeout(this.spinTimeout);
        }
        this.spinTimeout = setTimeout(async () => {
            await this.conn.reply(m.chat, `.pachi reset`);
            this.resetGame();
        }, 60000); // 1 menit
    }

    async endGame(m) {
        this.gameState = 'ended';
        let resultMessage = '🏁 *Permainan Berakhir!* \n\nHasil Akhir:\n';
        for (const player of this.players) {
            resultMessage += `${player.isBot ? '🤖' : '👤'} ${player.name}: ${player.money} money\n`;
        }
        const winner = this.players.reduce((prev, current) => (prev.money > current.money) ? prev : current);
        resultMessage += `\n🏆 Pemenang: ${winner.isBot ? '🤖' : '👤'} ${winner.name} dengan ${winner.money} money!`;

        await this.conn.reply(m.chat, resultMessage);
        await new Promise(resolve => setTimeout(resolve, 10000)); // Delay 10 detik
        await this.conn.reply(m.chat, `.pachi reset`);
        this.resetGame();
    }

    initializeGame() {
        this.gameState = 'playing';
        this.currentPlayerIndex = 0;
        this.roundCount = 0;
    }

    resetGame() {
        this.players = [];
        this.botPlayers = [];
        this.reelPositions = [0, 0, 0];
        this.jackpot = 10000;
        this.currentPlayerIndex = 0;
        this.gameState = 'lobby';
        this.roundCount = 0;
        if (this.spinTimeout) {
            clearTimeout(this.spinTimeout);
            this.spinTimeout = null;
        }
    }

    nextPlayer() {
        this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
        this.roundCount++;
    }
}

const handler = async (m, { conn, args, usedPrefix, command }) => {
    conn.pachirosuro = conn.pachirosuro || {};
    const sessions = conn.pachirosuro_ = conn.pachirosuro_ || {};
    const sessionId = m.chat;
    const session = sessions[sessionId] || (sessions[sessionId] = new GameSession(sessionId, conn));
    const game = session.game;
    const { state } = conn.pachirosuro[m.chat] || { state: false };

    switch (args[0]) {
        case 'join':
            if (state) return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat bergabung.');
            const playerName = m.sender;
            const joinSuccess = game.addPlayer(playerName);
            joinSuccess ? await conn.reply(m.chat, `👋 *${playerName} bergabung ke dalam permainan.*`) : await conn.reply(m.chat, '*Anda sudah bergabung atau permainan sudah penuh.* Tidak dapat bergabung.');
            break;

        case 'start':
            if (state) return await conn.reply(m.chat, '🛑 *Permainan sudah dimulai.* Tidak dapat memulai ulang.');
            conn.pachirosuro[m.chat] = { ...conn.pachirosuro[m.chat], state: true };
            await game.startGame(m);
            break;

        case 'spin':
            if (!state) return await conn.reply(m.chat, '🛑 *Permainan belum dimulai.* Ketik "!pachirosuro start" untuk memulai.');
            const currentPlayer = game.players[game.currentPlayerIndex];
            if (currentPlayer.isBot || m.sender !== currentPlayer.name) {
                return await conn.reply(m.chat, '🕒 Bukan giliran Anda atau ini giliran bot.');
            }
            const spinResult = game.spin(currentPlayer);
            await conn.reply(m.chat, spinResult);
            game.nextPlayer();
            await game.playRound(m);
            break;

        case 'reset':
            conn.pachirosuro[m.chat] = { ...conn.pachirosuro[m.chat], state: false };
            session.game.resetGame();
            await conn.reply(m.chat, '🔄 *Sesi permainan direset.*');
            break;

        case 'help':
            await conn.reply(m.chat, `🎰 *Pachirosuro (Mesin Slot)* 🎰

Pachirosuro adalah permainan mesin slot yang bisa dimainkan oleh pemain manusia dan bot.

*🎮 Cara Bermain:*
1. Pemain dapat bergabung dengan perintah 'join'.
2. Bot akan ditambahkan otomatis jika pemain kurang dari 4.
3. Setiap pemain memulai dengan saldo 1000 money.
4. Pemain memutar slot dengan taruhan 10 money per putaran.
5. Permainan berlangsung selama 10 putaran atau sampai semua pemain kehabisan saldo.

*🛠️ Perintah Permainan:*
• ${usedPrefix + command} join : Bergabung ke permainan
• ${usedPrefix + command} start : Memulai permainan
• ${usedPrefix + command} spin : Memutar slot (saat giliran Anda)
• ${usedPrefix + command} reset : Mengatur ulang sesi permainan

*💡 Fitur:*
- Jackpot: Dapatkan simbol "7️⃣" di semua 3 gulungan untuk memenangkan 10000 money.
- Bot otomatis: Bot akan ditambahkan dan bermain otomatis jika pemain kurang.

Selamat bermain dan semoga beruntung! 🍀`);
            break;

        default:
            await conn.reply(m.chat, `❓ *Perintah tidak valid.* Gunakan ${usedPrefix + command} help untuk melihat daftar perintah.`);
    }
};

handler.help = ['pachirosuro 𝐁𝐞𝐭𝐚'];
handler.tags = ['game'];
handler.command = /^(pachirosuro|pachi|pachisuro)$/i;

export default handler;