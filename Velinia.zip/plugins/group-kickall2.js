import { areJidsSameUser } from '@adiwajshing/baileys';

let handler = async (m, { conn, participants, isOwner }) => {
    if (!isOwner) return m.reply('Maaf, fitur ini hanya dapat digunakan oleh pemilik grup.');
    
    let admins = participants.filter(participant => participant.admin === 'admin' || participant.admin === 'superadmin');
    let demotedUsers = [];

    for (let admin of admins) {
        if (!areJidsSameUser(admin.id, conn.user.id)) { // Jangan demote diri sendiri
            try {
                const res = await conn.groupParticipantsUpdate(m.chat, [admin.id], 'demote');
                demotedUsers = demotedUsers.concat(res);
            } catch (error) {
                console.error(error);
            }
            await delay(1 * 1000); // Menunggu 1 detik sebelum melanjutkan
        }
    }

    if (demotedUsers.length > 0) {
        let mentionedUsers = demotedUsers.map(user => `@${user.split('@')[0]}`);
        m.reply(`Berhasil menurunkan status admin dari: ${mentionedUsers.join(', ')}`, null, { mentions: demotedUsers });
    } else {
        m.reply('Tidak ada admin lain yang dapat diturunkan.');
    }
};

handler.help = ['demoteall'];
handler.tags = ['group'];
handler.command = /^(demoteall)$/i;

handler.owner = true;
handler.group = true;
handler.botAdmin = true;

export default handler;

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));