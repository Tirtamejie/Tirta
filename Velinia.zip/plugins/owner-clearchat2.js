let handler = async (m, { conn }) => {
  try {
    // Kirim pesan pemberitahuan penghapusan
    const hapus = await conn.sendMessage(m.chat, { text: 'Menghapus pesan bot untuk semua orang...' }, { quoted: m, ephemeralExpiration: global.ephemeral });

    // Ambil semua obrolan
    const chats = Object.values(conn.chats);

    // Filter pesan yang dikirim oleh bot di semua obrolan
    const botMessages = [];
    for (const chat of chats) {
      for (const message of chat.messages) {
        if (message.fromMe) { // Identifikasi pesan yang dikirim oleh bot
          botMessages.push(message);
        }
      }
    }

    // Hapus pesan untuk semua orang
    for (const message of botMessages) {
      await conn.chatModify({ delete: true, forEveryone: true }, message.key.remoteJid, [message.key]);
    }

    // Kirim pesan konfirmasi
    await conn.sendMessage(m.chat, { text: `*Jumlah pesan dihapus:* ${botMessages.length}`, edit: hapus.key }, { quoted: m, ephemeralExpiration: global.ephemeral });
  } catch (error) {
    console.error(error);
    await conn.reply(m.chat, 'Terjadi kesalahan dalam menghapus pesan.', m);
  }
};

handler.help = ['clearchat2'];
handler.tags = ['owner'];
handler.owner = true;
handler.command = /^(clearchat2)$/i;

export default handler;