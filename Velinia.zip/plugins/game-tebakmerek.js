import fs from 'fs'
let timeout = 60000
let poin = 4999
let handler = async (m, { conn, command, usedPrefix }) => {
    conn.game = conn.game ? conn.game : {}
    let id = 'tebakmerek-' + m.chat
    if (id in conn.game) return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.game[id][0])
    let src = JSON.parse(fs.readFileSync('./json/tebakmerek.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `
Tebak merek dari gambar berikut:
${json.gambar}

Timeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${usedPrefix}merek untuk bantuan
Bonus: ${poin} XP
`.trim()
    conn.game[id] = [
        await m.reply(caption, { image: { url: json.gambar } }),
        json, poin,
        setTimeout(() => {
            if (conn.game[id]) conn.reply(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.game[id][0])
            delete conn.game[id]
        }, timeout)
    ]
}
handler.help = ['tebakmerek 𝐁𝐞𝐭𝐚']
handler.tags = ['game']
handler.command = /^tebakmerek$/i

handler.onlyprem = true
handler.game = true

export default handler