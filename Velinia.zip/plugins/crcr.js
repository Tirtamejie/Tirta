import fs from 'fs'

let handler = async (m, { conn }) => {
  let loadd = [
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《██████████▒▒▒》',
    '《█████████████》',
    '《██████████▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《██████████▒▒▒》',
    '《█████████████》',
    '《██████████▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《██████████▒▒▒》',
    '《█████████████》',
    '《██████████▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《██████████▒▒▒》',
    '《█████████████》',
    '《██████████▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《██████████▒▒▒》',
    '《█████████████》',
    '《██████████▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '*UDAH🗿*',
    '*GEDE🗿🗿*',
    '*MASI🗿🗿🗿*',
    '*CARI🗿🗿🗿🗿*',
    '*ESCEH🗿🗿🗿🗿🗿*',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《██████████▒▒▒》',
    '《█████████████》',
    '《██████████▒▒▒》',
    '《███████▒▒▒▒▒▒》',
    '《████▒▒▒▒▒▒▒▒▒》',
    '《██▒▒▒▒▒▒▒▒▒▒▒》',
    '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
  ];

  let { key } = await conn.sendMessage(m.chat, { text: '_Loading_' }); //Pengalih isu

  for (let i = 0; i < loadd.length; i++) {
    await new Promise(resolve => setTimeout(resolve, 1000)); // Delay 1 detik
    await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
  }

  let pfft = ` ❏ *_SCRIPT_*
 Hai kak 👋 Mau buy Script Hubungi Kami Ya
❏ https://wa.me/6283838348918
`;
  conn.sendMessage(m.chat, {
    text: pfft,
    contextInfo: {
      externalAdReply: {
        title: `© TinzBotz - Official`,
        body: global.author,
        thumbnailUrl: `https://files.catbox.moe/f5ppet.jpg`,
        sourceUrl: `https://whatsapp.com/channel/0029VakUeLS8fewly7GeTN2n`,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};

handler.command = /^(credits|sc)$/i;

export default handler;