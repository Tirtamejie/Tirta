import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    let res = await fetch('https://api.akuari.my.id/randomimage/ppcouple')
    if (!res.ok) throw new Error(`Error ${res.status}`)
    let json = await res.json()
    if (!json.hasil || !json.hasil.cowok || !json.hasil.cewek) throw new Error('Tidak dapat memperoleh data profile couple')
    let weem = '𝐑𝐚𝐧𝐝𝗼𝗺 𝐏𝐫𝗼𝐟𝐢𝐥𝐞 𝐂𝗼𝐮𝐩𝐥𝐞'
    await m.reply(wait)
    await conn.sendFile(m.chat, json.hasil.cowok, 'ppcouple.png', '𝙱𝚘𝚢𝚜', m)
    await conn.sendFile(m.chat, json.hasil.cewek, 'ppcouple.png', '𝙶𝚒𝚛𝚕𝚜', m)
  } catch (e) {
    console.error(e)
    m.reply('Terjadi kesalahan saat mengambil data.')
  }
}

handler.help = ['ppcp']
handler.tags = ['internet']
handler.command = /^(ppcouple2)|ppcp$/i

export default handler