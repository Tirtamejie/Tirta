import { Chess } from 'chess.js';

const handler = async (m, { conn, args }) => {
  const key = m.chat;
  conn.chess = conn.chess || {};
  let chessData = conn.chess[key] || {
    gameData: null,
    fen: null,
    currentTurn: null,
    players: [],
    hasJoined: [],
    isBot: false
  };
  conn.chess[key] = chessData;
  const { gameData, fen, currentTurn, players, hasJoined, isBot } = chessData;
  const feature = args[0]?.toLowerCase();

  function getRandomMove(chess) {
    const moves = chess.moves({ verbose: true });
    return moves[Math.floor(Math.random() * moves.length)];
  }

  if (feature === 'delete') {
    delete conn.chess[key];
    return conn.reply(m.chat, '🏳️ *Chess game stopped.*', m);
  }

  if (feature === 'create') {
    if (gameData) {
      return conn.reply(m.chat, '⚠️ *Game already in progress.*', m);
    }
    const isBot = args[1]?.toLowerCase() === 'bot';
    chessData.gameData = { status: 'waiting', black: null, white: null };
    chessData.isBot = isBot;
    return conn.reply(m.chat, `🎮 *Chess game started.*\n${isBot ? 'You will play against a bot.' : 'Waiting for other players to join.'}`, m);
  }

  if (feature === 'join') {
    const senderId = m.sender;
    if (players.includes(senderId)) {
      return conn.reply(m.chat, '🙅‍♂️ *You have already joined this game.*', m);
    }
    if (!gameData || gameData.status !== 'waiting') {
      return conn.reply(m.chat, '⚠️ *No chess game is currently waiting for players.*', m);
    }
    if (isBot && players.length >= 1) {
      return conn.reply(m.chat, '👥 *You are already playing against a bot.*', m);
    }
    if (players.length >= 2) {
      return conn.reply(m.chat, '👥 *Players are already enough.*\nThe game will start automatically.', m);
    }
    players.push(senderId);
    hasJoined.push(senderId);
    if (players.length === (isBot ? 1 : 2)) {
      gameData.status = 'ready';
      const [black, white] = Math.random() < 0.5 ? [players[1] || 'bot', players[0]] : [players[0], players[1] || 'bot'];
      gameData.black = black;
      gameData.white = white;
      chessData.currentTurn = white;
      return conn.reply(m.chat, `🙌 *Players who have joined:*\n${hasJoined.map(playerId => `- @${playerId.split('@')[0]}`).join('\n')}\n\n*Black:* ${black === 'bot' ? 'Bot' : `@${black.split('@')[0]}`}\n*White:* ${white === 'bot' ? 'Bot' : `@${white.split('@')[0]}`}\n\nPlease use *'chess start'* to begin the game.`, m, { mentions: hasJoined });
    } else {
      return conn.reply(m.chat, '🙋‍♂️ *You have joined the chess game.*\nWaiting for other players to join.', m);
    }
  }

  if (feature === 'start') {
    if (gameData.status !== 'ready') {
      return conn.reply(m.chat, '⚠️ *Cannot start the game. Wait for two players to join or set up a game with a bot.*', m);
    }
    gameData.status = 'playing';
    const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
    chessData.fen = fen;
    const encodedFen = encodeURIComponent(fen);
    const turn = `🎲 *Turn:* White ${gameData.white === 'bot' ? '(Bot)' : `@${gameData.white.split('@')[0]}`}`;
    const boardUrl = `https://www.chess.com/dynboard?fen=${encodedFen}&board=green&piece=neo&size=3`;
    try {
      await conn.sendFile(m.chat, boardUrl, '', turn, m, false, { mentions: gameData.white !== 'bot' ? [gameData.white] : [] });
    } catch (error) {
      console.error(error);
      return conn.reply(m.chat, '❌ *Error sending chess board. Please try again.*', m);
    }
    return;
  }

  if (args[0] && args[1]) {
    const senderId = m.sender;
    if (!gameData || gameData.status !== 'playing') {
      return conn.reply(m.chat, '⚠️ *The game has not started yet.*', m);
    }
    if (currentTurn !== senderId && currentTurn !== 'bot') {
      return conn.reply(m.chat, `⏳ *It's currently ${chessData.currentTurn === gameData.white ? 'White' : 'Black'}'s turn to move.*`, m, {
        mentions: [currentTurn]
      });
    }
    const chess = new Chess(fen);
    if (chess.isGameOver()) {
      delete conn.chess[key];
      let endMessage = '⚠️ *Game Over.*\n';
      if (chess.isCheckmate()) endMessage += `*Checkmate! Winner:* ${chess.turn() === 'w' ? 'Black' : 'White'}`;
      else if (chess.isDraw()) endMessage += '*Draw!*';
      else if (chess.isStalemate()) endMessage += '*Stalemate!*';
      else if (chess.isThreefoldRepetition()) endMessage += '*Draw by threefold repetition!*';
      else if (chess.isInsufficientMaterial()) endMessage += '*Draw by insufficient material!*';
      return conn.reply(m.chat, endMessage, m);
    }
    const [from, to] = args;
    try {
      chess.move({ from, to, promotion: 'q' });
    } catch (e) {
      return conn.reply(m.chat, '❌ *Invalid move.*', m);
    }
    chessData.fen = chess.fen();
    let turn = `🎲 *Last move:* ${from} to ${to}\n`;

    // Bot's move
    if (isBot && !chess.isGameOver()) {
      const botMove = getRandomMove(chess);
      chess.move(botMove);
      chessData.fen = chess.fen();
      turn += `🤖 *Bot moved:* ${botMove.from} to ${botMove.to}\n`;
    }

    const currentColor = chess.turn() === 'w' ? 'White' : 'Black';
    const currentPlayer = chess.turn() === 'w' ? gameData.white : gameData.black;
    turn += `🎲 *Turn:* ${currentColor} ${currentPlayer === 'bot' ? '(Bot)' : `@${currentPlayer.split('@')[0]}`}`;

    const encodedFen = encodeURIComponent(chess.fen());
    const boardUrl = `https://www.chess.com/dynboard?fen=${encodedFen}&board=green&piece=neo&size=3`;
    
    chessData.currentTurn = currentPlayer;

    try {
      await conn.sendFile(m.chat, boardUrl, '', turn, m, false, { mentions: currentPlayer !== 'bot' ? [currentPlayer] : [] });
    } catch (error) {
      console.error(error);
      return conn.reply(m.chat, '❌ *Error sending chess board. Please try again.*', m);
    }
    return;
  }

  if (feature === 'help') {
    return conn.reply(m.chat, `Perintah Permainan Catur:
 * .chess create: Mulai permainan catur baru
 * .chess create bot: Mulai permainan catur baru melawan bot
 * .chess join: Bergabung dengan permainan catur yang sudah ada
 * .chess start: Mulai permainan catur ketika semua pemain siap
 * .chess delete: Hentikan permainan catur saat ini
 * .chess [dari] [ke]: Lakukan gerakan dalam permainan catur
Cara Bermain Catur:
 * Permainan dimainkan di papan 8x8 dengan kotak-kotak berwarna terang dan gelap berselang-seling.
 * Setiap pemain memulai dengan 16 buah: 1 raja, 1 ratu, 2 benteng, 2 kuda, 2 gajah, dan 8 pion.
 * Tujuannya adalah melakukan skakmat pada raja lawan (menjebak raja sehingga tidak dapat menghindari penangkapan).
 * Putih selalu bergerak terlebih dahulu, kemudian pemain bergiliran menggerakkan satu buah catur pada setiap giliran.
Untuk menggerakkan sebuah buah, ketik .chess [dari] [ke] di mana [dari] adalah kotak awal dan [ke] adalah kotak tujuan.
Kotak-kotak diidentifikasi dengan huruf (a-h) untuk kolom dan angka (1-8) untuk baris.
Contoh gerakan:
 * .chess e2 e4: Menggerakkan pion dari e2 ke e4
 * .chess g1 f3: Menggerakkan kuda dari g1 ke f3
Selamat bermain!
    `, m);
  }
  return conn.reply(m.chat, '❓ Invalid command. Use *"chess help"* to see the available commands.', m);
};

handler.help = ['chess 𝐁𝐞𝐭𝐚'];
handler.tags = ['game'];
handler.command = /^(chess|catur)$/i;

export default handler;