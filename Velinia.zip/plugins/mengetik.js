let customerSessions = {}; // Store ongoing customer service sessions

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (command === 'cs') {
        if (text === 'buattiket') {
            let ticketNumber = Math.floor(Math.random() * 100000); // Generate a random ticket number
            customerSessions[m.sender] = {
                ticketNumber,
                lastActivity: Date.now()
            };
            return m.reply(`Tiket Anda telah dibuat. Nomor tiket: ${ticketNumber}\nGunakan perintah \`${usedPrefix}cs ${ticketNumber}|pesan\` untuk menghubungi agen.`);
        }

        if (!text) throw `*Cara penggunaan :*\n\n${usedPrefix + command} nomor_tiket|pesan\n\n*Contoh:* ${usedPrefix + command} 12345|Saya butuh bantuan.\n\nJika Anda tidak memiliki tiket, buatlah dengan menggunakan \`${usedPrefix + command} buattiket\`.`;

        let [ticketNumber, message] = text.split('|');
        if (!ticketNumber || !message) throw `*Cara penggunaan :*\n\n${usedPrefix + command} nomor_tiket|pesan\n\n*Contoh:* ${usedPrefix + command} 12345|Saya butuh bantuan.\n\nJika Anda tidak memiliki tiket, buatlah dengan menggunakan \`${usedPrefix + command} buattiket\`.`;

        if (isNaN(ticketNumber)) throw 'Nomor tiket harus berupa angka.';

        let csAgentJid = '6283160862238@s.whatsapp.net'; // Customer Service Agent's WhatsApp JID

        // Check for existing session
        if (!customerSessions[m.sender] || customerSessions[m.sender].ticketNumber != ticketNumber) {
            throw 'Tiket tidak ditemukan atau tidak valid. Harap periksa nomor tiket Anda.';
        }
        
        customerSessions[m.sender].lastActivity = Date.now(); // Update last activity time

        let responseMessage = `Hai agen, ada pesan baru dari pelanggan.\n\nNomor Tiket: *${ticketNumber}*\nPesan: ${message}\n\nSilakan balas ke pelanggan jika diperlukan.`.trim();

        let imgr = 'https://telegra.ph/file/6d369fd6d1256c0c47941.jpg'; // Sample image URL for message

        await conn.sendMessage(csAgentJid, { image: { url: imgr }, caption: responseMessage })
            .then(() => {
                m.reply('Pesan Anda telah berhasil dikirim ke agen layanan pelanggan.')
                return !0;
            });
    } else if (command === 'csbalas' && m.sender === '6283160862238@s.whatsapp.net') {
        // Handling replies from the agent
        let [ticketNumber, replyMessage] = text.split('|');
        if (!ticketNumber || !replyMessage) throw `*Cara penggunaan :*\n\n${usedPrefix + command} nomor_tiket|balasan\n\n*Contoh:* ${usedPrefix + command} 12345|Terima kasih atas pertanyaan Anda.`;

        let user = Object.keys(customerSessions).find(key => customerSessions[key].ticketNumber == ticketNumber);
        if (!user) throw 'Nomor tiket tidak valid atau sesi telah berakhir.';

        await conn.sendMessage(user, { text: `Balasan dari agen untuk tiket #${ticketNumber}:\n\n${replyMessage}` })
            .then(() => {
                customerSessions[user].lastActivity = Date.now();
                return !0;
            });
    }
};

// Check for inactive sessions every 5 minutes
setInterval(() => {
    let now = Date.now();
    for (let user in customerSessions) {
        if (now - customerSessions[user].lastActivity > 30 * 60 * 1000) { // 30 minutes inactivity
            delete customerSessions[user];
            conn.sendMessage(user, { text: 'Sesi dengan layanan pelanggan telah berakhir karena tidak ada aktivitas selama 30 menit. Silakan buat tiket baru jika Anda memerlukan bantuan lebih lanjut.' });
        }
    }
}, 5 * 60 * 1000);

handler.tags = ['customer_service']
handler.help = ['cs', 'csbalas'].map(v => v + ' <nomor_tiket|pesan>')
handler.command = /^(cs|csbalas)$/i
handler.private = true

export default handler