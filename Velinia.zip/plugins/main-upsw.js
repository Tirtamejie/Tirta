import fetch from "node-fetch";

const commandList = ["upsw"];

const mimeAudio = 'audio/mpeg';
const mimeVideo = 'video/mp4';
const mimeImage = 'image/jpeg';

let handler = async (m, { conn, command, args }) => {
  let teks
    if (args.length >= 1) {
        teks = args.slice(0).join(" ")
    } else if (m.quoted && m.quoted.text) {
        teks = m.quoted.text
    }

  if (m.quoted && m.quoted.mtype) {
    const mtype = m.quoted.mtype;
    let type;

    if (mtype === 'audioMessage') {
      type = 'vn';
    } else if (mtype === 'videoMessage') {
      type = 'vid';
    } else if (mtype === 'imageMessage') {
      type = 'img';
    } else if (mtype === 'extendedTextMessage') {
      type = 'txt';
    } else {
      throw "❌ Media type tidak valid!";
    }

    const doc = {};
    
    if (type === 'vn') {
      doc.mimetype = mimeAudio;
      doc.audio = await m.quoted.download();
    } else if (type === 'vid') {
      doc.mimetype = mimeVideo;
      doc.caption = teks;
      doc.video = await m.quoted.download();
    } else if (type === 'img') {
      doc.mimetype = mimeImage;
      doc.caption = teks;
      doc.image = await m.quoted.download();
    } else if (type === 'txt') {
      doc.text = teks;
    }
    
    await conn.sendMessage('status@broadcast', doc, {
      backgroundColor: getRandomHexColor(),
      font: Math.floor(Math.random() * 9),
      statusJidList: Object.keys(global.db.data.users)
    }).then((res) => {
      conn.reply(m.chat, `Sukses upload ${type}`, res);
    }).catch(() => {
      conn.reply(m.chat, `Gagal upload ${type}`, m);
    });
  } else {
    throw "❌ Tidak ada media yang diberikan!";
  }
};

handler.help = commandList;
handler.tags = ["owner"];
handler.owner = true;
handler.rowner = true
handler.command = new RegExp(`^(${commandList.join('|')})$`, 'i');

export default handler;

function getRandomHexColor() {
  return "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
}