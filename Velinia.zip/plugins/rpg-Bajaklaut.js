let handler = async (m, { conn }) => {
    // Hitung timer yang tersisa sampai petualangan berikutnya
    let remainingTime = (60000 - (new Date - global.db.data.users[m.sender].lastPirateAdventure));

    // Pastikan remainingTime tidak minus
    remainingTime = Math.max(remainingTime, 0);

    let timers = clockString(remainingTime); // Ubah remainingTime menjadi string timer
    let name = conn.getName(m.sender);
    let user = global.db.data.users[m.sender];
    let id = m.sender;
    let role = 'Pirate Captain';
    conn.pirate = conn.pirate ? conn.pirate : {};

    // Cek apakah ada petualangan yang sedang berlangsung
    if (id in conn.pirate) {
        conn.reply(m.chat, `Selesaikan Petualangan ${conn.pirate[id][0]} Terlebih Dahulu`, m);
        return false;
    }

    // Cek apakah timer sudah selesai (remainingTime = 0)
    if (remainingTime === 0) {
        let randomGold = Math.floor(Math.random() * 200) + 200;
        let randomExp = Math.floor(Math.random() * 40) + 40;
        let battleSuccess = Math.random() > 0.5;

        let goldEarned = randomGold;
        let expEarned = randomExp;
        let battleOutcome = battleSuccess;

        let key1 = await conn.sendMessage(m.chat, { text: ' Mempersiapkan petualangan bajak laut berikutnya...' });
        
        await new Promise(resolve => setTimeout(resolve, 5000));
        let message = `
‍☠️⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬜⬜⬜⬜⬜⬜⬜⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛
⛵
✔️ Mendapatkan peta harta karun...
`.trim();
        await conn.sendMessage(m.chat, { text: message, edit: key1 });
        
        await new Promise(resolve => setTimeout(resolve, 10000));
        message = `
️⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬜⬜⬜⬜⬜⬜⬜⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛
⛵
➕ Berlayar menuju pulau tersembunyi...
`.trim();
        await conn.sendMessage(m.chat, { text: message, edit: key1 });
        
        await new Promise(resolve => setTimeout(resolve, 10000));
        message = `
⚔️⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬜⬜⬜⬜⬜⬜⬜⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛
⛵
➕ Terlibat pertempuran laut...
`.trim();
        await conn.sendMessage(m.chat, { text: message, edit: key1 });
        
        await new Promise(resolve => setTimeout(resolve, 5000));
        message = battleOutcome ? `
 Kemenangan! Kapal musuh berhasil dikalahkan.
` : `
❌ Kekalahan! Kapalmu mengalami kerusakan.
`;
        await conn.sendMessage(m.chat, { text: message, edit: key1 });
        
        await new Promise(resolve => setTimeout(resolve, 10000));
        message = `
⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬜⬜⬜⬜⬜⬜⬜⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛
⛵
➕ Menemukan harta karun tersembunyi...
`.trim();
        await conn.sendMessage(m.chat, { text: message, edit: key1 });
        
        let result = `
*—[ Hasil Petualangan Bajak Laut ${name} ]—*
✔️ Petualangan selesai! Pertempuran: ${battleOutcome ? "Menang" : "Kalah"}
➕  Emas = [ ${goldEarned} ]
➕ ✨ Exp = [ ${expEarned} ]
➕ ‍☠️ Petualangan Selesai = +1
➕  Total Petualangan Sebelumnya : ${user.adventuresCompleted}
`.trim();
        
        user.gold += goldEarned;
        user.exp += expEarned;
        user.adventuresCompleted += 1;

        conn.pirate[id] = [
            role,
            setTimeout(() => {
                delete conn.pirate[id];
            }, 50000)
        ];
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        await conn.sendMessage(m.chat, { text: result }, { quoted: key1 });
        
        user.lastPirateAdventure = new Date * 1
    } else m.reply(`Silahkan Menunggu Selama ${timers}, Untuk Memulai Petualangan Bajak Laut Baru`)
}
handler.help = ['bajakalaut 𝐁𝐚𝐫𝐮']
handler.tags = ['rpg']
handler.command = /^(bajakalaut)$/i
handler.register = true
handler.group = true
handler.rpg = true
export default handler

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}