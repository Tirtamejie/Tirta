class GameSession {
    constructor(id, sMsg) {
        this.id = id;
        this.players = [];
        this.game = new TebakBomGame(sMsg);
    }
}

class TebakBomGame {
    constructor(sMsg) {
        this.sendMsg = sMsg;
        this.players = [];
        this.boardSize = 9; // 3x3 grid
        this.bombPosition = Math.floor(Math.random() * this.boardSize) + 1;
        this.currentPlayerIndex = 0;
        this.started = false;
        this.revealedPositions = new Set();
        this.keyId = null;
        this.theme = 'default'; // default theme
        this.powerUps = {}; // store power-ups for each player
        this.botPlayer = 'bot'; // Identifier for the bot player
    }

    setTheme(theme) {
        const themes = {
            default: { bomb: '💣', safe: '✅' },
            ocean: { bomb: '🐙', safe: '🐠' },
            space: { bomb: '🚀', safe: '🪐' },
        };
        this.theme = themes[theme] || themes['default'];
    }

    initializeGame(withBot = false) {
        this.currentPlayerIndex = 0;
        this.started = true;
        this.bombPosition = Math.floor(Math.random() * this.boardSize) + 1;
        this.powerUps = {
            [this.players[0]]: { reveal: 1 },
            [this.players[1]]: { reveal: 1 }
        };
        if (withBot) {
            this.players[1] = this.botPlayer; // Set bot as second player
        }
    }

    async startGame(m, withBot = false) {
        const player1 = this.players[0];
        const player2 = withBot ? 'Bot' : this.players[1];
        await m.reply(`💣 *Selamat datang di Permainan Tebak Bom!* 💣\n\n@${player1.split('@')[0]} vs ${player2}`, null, {
            mentions: [player1].filter(p => p !== this.botPlayer) // Only mention real players
        });
        this.initializeGame(withBot);
        await this.sendBoard(m);
        if (withBot && this.players[this.currentPlayerIndex] === this.botPlayer) {
            await this.botPlayTurn(m);
        }
    }

    async sendBoard(m) {
        let boardText = '❏  *TEBAK BOM*\n\nKirim angka *1* - *9* untuk membuka kotak:\n\n';
        for (let i = 1; i <= this.boardSize; i++) {
            boardText += this.revealedPositions.has(i) ? this.theme.safe + ' ' : `${i}️⃣ `;
            if (i % 3 === 0) boardText += '\n';
        }
        await m.reply(boardText);
    }

    async playTurn(m, player, position) {
        if (position < 1 || position > this.boardSize || this.revealedPositions.has(position)) {
            await m.reply('⚠️ Pilih kotak yang valid dan belum dibuka.');
            return;
        }
        
        if (position === this.bombPosition) {
            await m.reply(`${this.theme.bomb} BOOM! ${player === this.botPlayer ? 'Bot' : `@${player.split('@')[0]}`} menemukan bom!`, null, { mentions: [player].filter(p => p !== this.botPlayer) });
            this.resetSession();
        } else {
            this.revealedPositions.add(position);
            await m.reply(`✅ Aman! ${player === this.botPlayer ? 'Bot' : `@${player.split('@')[0]}`} berhasil membuka kotak ${position}.`, null, { mentions: [player].filter(p => p !== this.botPlayer) });

            this.switchPlayer();
            
            await this.sendBoard(m);
            if (this.players[this.currentPlayerIndex] === this.botPlayer) {
                await this.botPlayTurn(m);
            }
        }
    }

    async botPlayTurn(m) {
        let availablePositions = Array.from({ length: this.boardSize }, (_, i) => i + 1).filter(pos => !this.revealedPositions.has(pos));
        let botChoice = availablePositions[Math.floor(Math.random() * availablePositions.length)];
        await m.reply(`🤖 Bot memilih kotak ${botChoice}.`);
        await this.playTurn(m, this.botPlayer, botChoice);
    }

    switchPlayer() {
        this.currentPlayerIndex = 1 - this.currentPlayerIndex;
    }

    resetSession() {
        this.players = [];
        this.revealedPositions.clear();
        this.started = false;
        this.bombPosition = Math.floor(Math.random() * this.boardSize) + 1;
    }

    addPlayer(player) {
        if (this.players.length < 2 && !this.players.includes(player)) {
            this.players.push(player);
            return true;
        }
        return false;
    }
}

const handler = async (m, { conn, args, usedPrefix, command }) => {
    conn.tebakbom = conn.tebakbom || {};
    const sessions = conn.tebakbom_ = conn.tebakbom_ || {};
    const sessionId = m.chat;
    const session = sessions[sessionId] || (sessions[sessionId] = new GameSession(sessionId, conn));
    const game = session.game;

    switch (args[0]) {
        case 'join':
            const playerName = m.sender;
            const joinSuccess = game.addPlayer(playerName);
            joinSuccess ? m.reply(`👋 @${playerName.split('@')[0]} bergabung ke dalam permainan.`, null, { mentions: [playerName] }) : m.reply('*Anda sudah bergabung atau permainan sudah penuh.*');
            break;

        case 'start':
            if (game.players.length === 2 || (game.players.length === 1 && args[1] === 'bot')) {
                const withBot = args[1] === 'bot';
                await game.startGame(m, withBot);
            } else {
                await m.reply('👥 *Tidak cukup pemain untuk memulai permainan.* Diperlukan 2 pemain atau 1 pemain melawan bot.');
            }
            break;

        case 'pick':
            if (!game.started) return m.reply('🛑 *Permainan belum dimulai.* Ketik "!bomb start" untuk memulai.');
            const currentPlayer = game.players[game.currentPlayerIndex];
            const position = parseInt(args[1]);
            if (m.sender !== currentPlayer) {
                await m.reply(`🕒 *Bukan giliranmu.* Sekarang giliran @${currentPlayer.split('@')[0]}`, null, { mentions: [currentPlayer].filter(p => p !== game.botPlayer) });
            } else if (isNaN(position) || position < 1 || position > 9) {
                await m.reply('⚠️ Pilih kotak yang valid antara 1 dan 9.');
            } else {
                await game.playTurn(m, currentPlayer, position);
            }
            break;

        case 'powerup':
            if (!game.started) return m.reply('🛑 *Permainan belum dimulai.* Ketik "!bomb start" untuk memulai.');
            const powerUpType = args[1];
            if (powerUpType === 'reveal') {
                game.usePowerUp(m, m.sender, powerUpType);
            } else {
                m.reply('⚠️ Jenis power-up tidak valid.');
            }
            break;

        case 'theme':
            const theme = args[1];
            game.setTheme(theme);
            await m.reply(`🎨 Tema diatur ke ${theme}.`);
            break;

        case 'reset':
            session.game.resetSession();
            delete sessions[sessionId];
            await m.reply('🔄 *Sesi permainan direset.*');
            break;

        case 'help':
            await m.reply(`💣 *Permainan Tebak Bom* 💣\n\n*Cara Bermain:*\n- Dua pemain bergantian memilih kotak.\n- Jika kotak yang dipilih berisi bom, pemain kalah.\n- Pemain yang bertahan terlama menang.\n\n*Perintah:*\n• ${usedPrefix + command} join  : Bergabung ke dalam permainan\n• ${usedPrefix + command} start : Memulai permainan\n• ${usedPrefix + command} pick <nomor> : Memilih kotak\n• ${usedPrefix + command} powerup <reveal> : Menggunakan power-up\n• ${usedPrefix + command} theme <default|ocean|space> : Mengganti tema\n• ${usedPrefix + command} reset : Mengatur ulang sesi permainan\n• ${usedPrefix + command} start bot : Bermain melawan bot`);
            break;

        default:
            m.reply(`❓ *Perintah tidak valid.* Gunakan ${usedPrefix + command} help untuk melihat daftar perintah.`);
    }
};

handler.help = ['bombpvp 𝐁𝐚𝐫𝐮+𝐁𝐞𝐭𝐚'];
handler.tags = ['game'];
handler.command = /^(bombpvp)$/i;

export default handler;