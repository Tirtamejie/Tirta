import fs from 'fs'
import { join } from 'path'

let handler = async (m, {
    conn,
    args,
    text,
    usedPrefix,
    command
}) => {
    let input = `[!] *Wrong input*

Example: ${usedPrefix + command} 6282276553463|index.js`

    if (!text) return m.reply(input)
    
    let [no, file] = text.split('|').map(v => v.trim())
    
    if (!no || !file) return m.reply(input)
    
    // Validate phone number
    if (!/^[0-9]+$/.test(no)) return m.reply('Invalid phone number. Please use numbers only.')
    
    // Check if file exists
    const filePath = join('./', file)
    if (!fs.existsSync(filePath)) return m.reply(`File "${file}" not found.`)
    
    try {
        let user_bot = await fs.promises.readFile(filePath)
        await conn.sendMessage(no + '@s.whatsapp.net', {
            document: user_bot,
            caption: 'Here\'s the script you requested.',
            mimetype: 'application/javascript', // Adjust based on file type
            fileName: file
        })
        m.reply('Successfully sent file to ' + no)
    } catch (error) {
        console.error(error)
        m.reply('An error occurred while sending the file.')
    }
}

handler.help = ['sendsc <number>|<filename>']
handler.tags = ['owner']
handler.command = /^(sendsc)$/i
handler.rowner = true

export default handler