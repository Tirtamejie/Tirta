
import Jimp from 'jimp';
import axios from 'axios';

class GameSession {
    constructor(id, sMsg) {
        this.id = id;
        this.players = [];
        this.game = new LudoGame(sMsg);
    }
}

class LudoGame {
    constructor(sMsg) {
        this.sendMsg = sMsg;
        this.players = [];
        this.boardSize = 52;
        this.homeSpaces = 6;
        this.currentPositions = {};
        this.currentPlayerIndex = 0;
        this.coloredPaths = {
            red: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60],
            green: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60],
            blue: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60],
            yellow: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60]
        };
        this.eatenTokens = {
            red: [],
            green: [],
            blue: [],
            yellow: []
        };
        this.bgImageUrl = 'https://files.catbox.moe/l977j9.jpg';
        this.playerColors = ['red', 'blue', 'green', 'yellow'];
        this.bgImage = null;
        this.playerTokens = {};
        this.cellWidth = 40;
        this.cellHeight = 40;
        this.keyId = null;
        this.started = false;
        this.botPlayers = [];
        this.botDifficulty = 'normal';
    }

    initializeGame() {
        for (const player of this.players) {
            this.currentPositions[player] = {
                tokens: [0, 0, 0, 0],
                home: 0
            };
        }
        this.currentPlayerIndex = 0;
        this.started = true;
    }

    rollDice() {
        return Math.floor(Math.random() * 6) + 1;
    }

    async moveToken(player, tokenIndex, steps) {
        const playerData = this.currentPositions[player];
        let currentPosition = playerData.tokens[tokenIndex];
        
        if (currentPosition === 0 && steps === 6) {
            playerData.tokens[tokenIndex] = 1;
            return true;
        }

        if (currentPosition === 0) return false;

        let newPosition = currentPosition + steps;
        if (newPosition > this.boardSize) {
            const remainingSteps = newPosition - this.boardSize;
            if (remainingSteps <= this.homeSpaces) {
                playerData.home += 1;
                playerData.tokens[tokenIndex] = 0;
                if (playerData.home === 4) {
                    return 'win';
                }
                return true;
            }
            return false;
        }

        playerData.tokens[tokenIndex] = newPosition;
        return true;
    }

    async fetchImage(url) {
        try {
            const response = await axios.get(url, { responseType: 'arraybuffer' });
            return await Jimp.read(Buffer.from(response.data, 'binary'));
        } catch (error) {
            console.error(`Error fetching image from ${url}:`, error);
            throw error;
        }
    }

    async getBoardBuffer() {
        const board = new Jimp(420, 420);
        this.bgImage.resize(420, 420);
        board.composite(this.bgImage, 0, 0);

        for (let i = 0; i < this.players.length; i++) {
            const player = this.players[i];
            const playerData = this.currentPositions[player];
            const color = this.playerColors[i];

            for (let j = 0; j < 4; j++) {
                const tokenPosition = playerData.tokens[j];
                if (tokenPosition > 0) {
                    let x, y;
                    if (tokenPosition <= 52) {
                        x = ((tokenPosition - 1) % 13) * this.cellWidth + 10;
                        y = Math.floor((tokenPosition - 1) / 13) * this.cellHeight + 10;
                    } else if (tokenPosition <= 56) {
                        x = (tokenPosition - 53) * this.cellWidth + 10;
                        y = 360;
                    } else {
                        x = (tokenPosition - 57) * this.cellWidth + 10;
                        y = 380;
                    }
                    const token = new Jimp(this.cellWidth - 20, this.cellHeight - 20, Jimp.cssColorToHex(color));
                    board.composite(token, x, y);
                }
            }
        }

        return board.getBufferAsync(Jimp.MIME_PNG);
    }

    async startGame(m, playerNames) {
        const mentions = playerNames.map(name => `@${name.split('@')[0]}`).join(', ');
        await m.reply(`🎲 *Selamat datang di Permainan Ludo!* 🎲\n\nPemain: ${mentions}`, null, { mentions: playerNames });
        this.players = playerNames;
        this.initializeGame();

        let pathInfo = '📍 *Jalur Khusus Warna:*\n';
        for (const color in this.coloredPaths) {
            pathInfo += `\n*${color.toUpperCase()}:* ${this.coloredPaths[color].join(', ')}`;
        }
        await m.reply(pathInfo);

        if (!this.bgImage) {
            this.bgImage = await this.fetchImage(this.bgImageUrl);
        }

        const boardBuffer = await this.getBoardBuffer();
        const { key } = await m.reply(boardBuffer);
        this.keyId = key;
    }

    async eatToken(player, targetPlayer) {
        const playerColor = this.getPlayerColor(player);
        const targetColor = this.getPlayerColor(targetPlayer);

        const targetTokenPosition = this.currentPositions[targetPlayer];
        if (this.coloredPaths[playerColor].includes(targetTokenPosition)) {
            this.eatenTokens[targetColor].push(targetTokenPosition);
            this.currentPositions[targetPlayer] = 0;
            await this.sendMsg.reply(m.chat, `🍽️ @${player.split('@')[0]} memakan token @${targetPlayer.split('@')[0]}!`, null, { mentions: [player, targetPlayer] });
        } else {
            await this.sendMsg.reply(m.chat, `❌ @${player.split('@')[0]} tidak dapat memakan token @${targetPlayer.split('@')[0]} karena tidak berada di posisi yang sama.`, null, { mentions: [player, targetPlayer] });
        }
    }

    getPlayerColor(player) {
        const index = this.players.indexOf(player);
        return this.playerColors[index] || null;
    }

    async movePlayer(player, steps) {
        const playerColor = this.getPlayerColor(player);
        let currentPosition = this.currentPositions[player];
        let newPosition = currentPosition + steps;

        if (this.coloredPaths[playerColor].includes(currentPosition)) {
            if (this.coloredPaths[playerColor].includes(newPosition)) {
                this.currentPositions[player] = newPosition;
            } else {
                this.currentPositions[player] = 0;
            }
        } else {
            this.currentPositions[player] = newPosition;
        }

        for (const otherPlayer of this.players) {
            if (otherPlayer !== player && this.currentPositions[otherPlayer] === this.currentPositions[player]) {
                await this.eatToken(player, otherPlayer);
            }
        }

        await this.sendMsg.reply(m.chat, `🎲 @${player.split('@')[0]} bergerak ${steps} langkah ke posisi ${this.currentPositions[player]}.`, null, { mentions: [player] });
    }

    async playTurn(m, player) {
        if (!this.players.length) {
            await m.reply('🛑 *Tidak ada permainan aktif.* Gunakan "!ludo start" untuk memulai permainan baru.');
            return;
        }
        if (player !== this.players[this.currentPlayerIndex]) {
            await m.reply(`🕒 *Bukan giliranmu.* \n\nSekarang giliran @${this.players[this.currentPlayerIndex].split('@')[0]}`, null, {
                mentions: [this.players[this.currentPlayerIndex]]
            });
            return;
        }

        if (this.botPlayers.includes(this.currentPlayerIndex)) {
            await this.playBotTurn(m);
        } else {
            const diceRoll = this.rollDice();
            await m.reply(`🎲 @${player.split('@')[0]} *melempar dadu.*\n\n  - Hasil: *${diceRoll}*`, null, { mentions: [player] });

            const playerData = this.currentPositions[player];
            let moved = false;

            for (let i = 0; i < 4; i++) {
                if (await this.moveToken(player, i, diceRoll)) {
                    moved = true;
                    await m.reply(`🚶 Token ${i+1} bergerak ${diceRoll} langkah.`);
                    break;
                }
            }

            if (!moved) {
                await m.reply('😔 Tidak ada gerakan yang mungkin.');
            }

            if (playerData.home === 4) {
                await m.reply(`🎉 @${player.split('@')[0]} menang! Selamat!`, null, { mentions: [player] });
                this.resetSession();
            } else if (diceRoll !== 6) {
                this.switchPlayer();
            } else {
                await m.reply('🎲 Anda mendapat 6, jadi giliran Anda masih berlanjut.');
            }
        }

        const boardBuffer = await this.getBoardBuffer();
        const sendMsg = this.sendMsg;
        await sendMsg.sendMessage(m.chat, { delete: this.keyId });
        const { key } = await m.reply(boardBuffer);
        this.keyId = key;
    }

    async playBotTurn(m) {
        const botPlayer = this.players[this.currentPlayerIndex];
        const diceRoll = this.rollDice();
        await m.reply(`🤖 Bot @${botPlayer.split('@')[0]} *melempar dadu.*\n\n  - Hasil: *${diceRoll}*`, null, { mentions: [botPlayer] });

        let moved = false;
        const playerData = this.currentPositions[botPlayer];

        switch (this.botDifficulty) {
            case 'easy':
                for (let i = 0; i < 4; i++) {
                    if (await this.moveToken(botPlayer, i, diceRoll)) {
                        moved = true;
                        await m.reply(`🤖 Bot menggerakkan Token ${i+1} sebanyak ${diceRoll} langkah.`);
                        break;
                    }
                }
                break;
            case 'normal':
                let bestMove = -1;
                for (let i = 0; i < 4; i++) {
                    if (await this.canEatOpponent(botPlayer, i, diceRoll)) {
                        bestMove = i;
                        break;
                    }
                }
                if (bestMove === -1) {
                    bestMove = this.getFurthestToken(botPlayer);
                }
                if (bestMove !== -1 && await this.moveToken(botPlayer, bestMove, diceRoll)) {
                    moved = true;
                    await m.reply(`🤖 Bot menggerakkan Token ${bestMove+1} sebanyak ${diceRoll} langkah.`);
                }
                break;
            case 'hard':
                // Implementasi strategi yang lebih kompleks untuk bot sulit
                break;
        }

        if (!moved) {
            await m.reply('🤖 Bot tidak dapat melakukan gerakan.');
        }

        if (playerData.home === 4) {
            await m.reply(`🎉 Bot @${botPlayer.split('@')[0]} menang!`, null, { mentions: [botPlayer] });
            this.resetSession();
        } else if (diceRoll !== 6) {
            this.switchPlayer();
        } else {
            await m.reply('🎲 Bot mendapat 6, jadi gilirannya masih berlanjut.');
            await this.playBotTurn(m);
        }
    }

    async canEatOpponent(player, tokenIndex, steps) {
        const playerData = this.currentPositions[player];
        const currentPosition = playerData.tokens[tokenIndex];
        const newPosition = currentPosition + steps;
        
        for (const otherPlayer of this.players) {
            if (otherPlayer !== player) {
                const otherPlayerData = this.currentPositions[otherPlayer];
                for (let i = 0; i < 4; i++) {
                    if (otherPlayerData.tokens[i] === newPosition) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    getFurthestToken(player) {
        const playerData = this.currentPositions[player];
        let furthestToken = -1;
        let maxDistance = -1;
        
        for (let i = 0; i < 4; i++) {
            if (playerData.tokens[i] > maxDistance) {
                maxDistance = playerData.tokens[i];
                furthestToken = i;
            }
        }
        
        return furthestToken;
    }

    addPlayer(player, isBot = false) {
        if (this.players.length < 4 && !this.players.includes(player) && player !== '') {
            this.players.push(player);
            if (isBot) {
                this.botPlayers.push(this.players.length - 1);
            }
            return true;
        } else {
            return false;
        }
    }

    switchPlayer() {
        this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
    }

    resetSession() {
        this.players = [];
        this.currentPositions = {};
        this.currentPlayerIndex = 0;
        this.started = false;
        this.botPlayers = [];
    }

    isGameStarted() {
        return this.started;
    }

    setBotDifficulty(difficulty) {
        if (['easy', 'normal', 'hard'].includes(difficulty)) {
            this.botDifficulty = difficulty;
            return true;
        }
        return false;
    }
}

const handler = async (m, { conn, args, usedPrefix, command }) => {
    conn.ludo = conn.ludo || {};
    const sessions = conn.ludo_ = conn.ludo_ || {};
    const sessionId = m.chat;
    const session = sessions[sessionId] || (sessions[sessionId] = new GameSession(sessionId, conn));
    const game = session.game;
    const { state } = conn.ludo[m.chat] || { state: false };

    switch (args[0]) {
        case 'join':
            if (state) return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat bergabung.');
            const playerName = m.sender;
            const joinSuccess = game.addPlayer(playerName);
            joinSuccess ? m.reply(`👋 @${playerName.split('@')[0]} *bergabung ke dalam permainan.*`, null, { mentions: [playerName] }) : m.reply('*Anda sudah bergabung atau permainan sudah penuh.* Tidak dapat bergabung.');
            break;

        case 'addbot':
            if (state) return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat menambahkan bot.');
            const botName = `Bot${game.players.length + 1}`;
            const addBotSuccess = game.addPlayer(botName, true);
            addBotSuccess ? m.reply(`🤖 Bot ${botName} telah ditambahkan ke dalam permainan.`) : m.reply('Tidak dapat menambahkan bot. Permainan mungkin sudah penuh.');
            break;

        case 'setbotdifficulty':
            if (state) return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat mengubah tingkat kesulitan bot.');
            if (args.length < 2) return m.reply(`Format: ${usedPrefix + command} setbotdifficulty <easy/normal/hard>`);
            const difficulty = args[1].toLowerCase();
            const setDifficultySuccess = game.setBotDifficulty(difficulty);
            setDifficultySuccess ? m.reply(`✅ Tingkat kesulitan bot diatur ke: ${difficulty}`) : m.reply('❌ Tingkat kesulitan tidak valid. Pilih antara easy, normal, atau hard.');
            break;

        case 'start':
            if (state) return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat memulai ulang.');
            conn.ludo[m.chat] = { ...conn.ludo[m.chat], state: true };
            if (game.players.length >= 2 && game.players.length <= 4) {
                await game.startGame(m, game.players);
            } else {
                await m.reply('👥 *Jumlah pemain tidak sesuai.* Diperlukan 2-4 pemain.');
            }
            break;

        case 'roll':
            if (!state) return m.reply('🛑 *Permainan belum dimulai.* Ketik "!ludo start" untuk memulai.');
            if (game.isGameStarted()) {
                const currentPlayer = game.players[game.currentPlayerIndex];
                if (m.sender !== currentPlayer && !game.botPlayers.includes(game.currentPlayerIndex)) {
                    await m.reply(`🕒 *Bukan giliranmu.* \n\nSekarang giliran @${currentPlayer.split('@')[0]}`, null, { mentions: [currentPlayer] });
                } else {
                    await game.playTurn(m, currentPlayer);
                }
            } else {
                await m.reply('🛑 *Permainan belum dimulai.* Ketik "!ludo start" untuk memulai.');
            }
            break;

        case 'reset':
            conn.ludo[m.chat] = { ...conn.ludo[m.chat], state: false };
            session.game.resetSession();
            delete sessions[sessionId];
            await m.reply('🔄 *Sesi permainan direset.*');
            break;

        case 'help':
            await m.reply(`🎲 *Permainan Ludo* 🎲

Ludo adalah permainan papan klasik untuk 2-4 pemain. Setiap pemain memiliki 4 token yang harus dibawa dari 'rumah' ke 'tujuan' dengan melempar dadu.

*🎮 Cara Bermain:*
1. Setiap pemain memiliki 4 token berwarna yang dimulai dari start.
2. Pemain melempar dadu untuk menentukan berapa langkah yang dapat diambil.
3. Jika token pemain mendarat di posisi yang sama dengan token lawan, token lawan akan "dimakan" dan harus kembali ke start.
4. Setiap pemain memiliki jalur khusus berwarna yang harus diikuti.

*👥 Jumlah Pemain:* 2-4 pemain (termasuk bot)

*🛠️ Perintah Permainan:*
• ${usedPrefix + command} join  : Bergabung ke dalam permainan
• ${usedPrefix + command} addbot : Menambahkan bot ke dalam permainan
• ${usedPrefix + command} setbotdifficulty <easy/normal/hard> : Mengatur tingkat kesulitan bot
• ${usedPrefix + command} start : Memulai permainan
• ${usedPrefix + command} roll  : Melempar dadu dan bergerak
• ${usedPrefix + command} reset : Mengatur ulang sesi permainan

*💡 Tips Bermain:*
- Perhatikan jalur khusus warna Anda saat bergerak.
- Berusahalah untuk memakan token lawan saat ada kesempatan.
- Jaga jarak dengan token lawan untuk menghindari dimakan.
- Strategi dan keberuntungan adalah kunci kemenangan dalam Ludo!
- Keluarkan semua token Anda secepat mungkin.
- Blokir jalan lawan jika memungkinkan.
- Prioritaskan token yang sudah jauh dari 'rumah'.

Selamat bermain dan semoga beruntung! 🍀`);
            break;

        default:
            m.reply(`❓ *Perintah tidak valid.* Gunakan ${usedPrefix + command} help untuk melihat daftar perintah.`);
    }
};

handler.help = ['ludo 𝐁𝐚𝐫𝐮+𝐁𝐞𝐭𝐚']
handler.tags = ['game']
handler.command = /^(ludo|ludoking)$/i
handler.group = true
handler.game = true

export default handler