import { generateWAMessageFromContent } from '@adiwajshing/baileys'

let handler = async (m, { conn, text }) => {
  let users = m.mentionedJid.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  let q = m.quoted ? m.quoted : m
  let c = m.quoted ? m.quoted : m.msg
  let content = q.mtype === 'conversation' ? q.text : q.mtype === 'imageMessage' ? q.caption : q.mtype === 'videoMessage' ? q.caption : q.mtype === 'extendedTextMessage' ? q.text : q.mtype === 'buttonsResponseMessage' ? q.selectedButtonId : q.mtype === 'listResponseMessage' ? q.singleSelectReply.selectedRowId : q.mtype === 'templateButtonReplyMessage' ? q.selectedId : q.mtype === 'messageContextInfo' ? (q.quoted.mtype === 'conversation' ? q.quoted.text : q.quoted.mtype === 'imageMessage' ? q.quoted.caption : q.quoted.mtype === 'videoMessage' ? q.quoted.caption : q.quoted.mtype === 'extendedTextMessage' ? q.quoted.text : q.quoted.mtype === 'buttonsResponseMessage' ? q.quoted.selectedButtonId : q.quoted.mtype === 'listResponseMessage' ? q.quoted.singleSelectReply.selectedRowId : q.quoted.mtype === 'templateButtonReplyMessage' ? q.quoted.selectedId : '') : ''
  const msg = conn.cMod(m.chat,
    generateWAMessageFromContent(m.chat, {
      [c.toJSON ? q.mtype : 'extendedTextMessage']: c.toJSON ? c.toJSON() : {
        text: text || content || ''
      }
    }, {
      quoted: m,
      userJid: conn.user.id
    }),
    text || content, conn.user.jid, { mentions: users }
  )
  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ['hidetag'].map(v => v + ' [teks]')
handler.tags = ['group', 'adminry']
handler.command = /^(hidetag|htag|h)$/i

handler.group = true
handler.admin = false
handler.owner = true

export default handler