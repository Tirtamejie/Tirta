import fs from "fs";

let handler = async (m, { conn }) => {
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
    if (!(who in global.db.data.users)) return m.reply(`User ${who} tidak ada dalam database`);

    let user = global.db.data.users[who];
    const caption = `
▧「 *BANK CEK* 」
│ 👤 Nama: ${user.registered ? user.name : conn.getName(m.sender)}
│ 💳 Atm: ${user.atm > 0 ? 'Level ' + user.atm : '✖️'}
│ 🏦 Bank: ${user.bank ? user.bank.toLocaleString('id-ID') : '0'} / ${user.fullatm ? user.fullatm.toLocaleString('id-ID') : '0'}
│ 💰 Uang: ${user.money ? user.money.toLocaleString('id-ID') : '0'}
│ 💳 Chip: ${user.chip ? user.chip.toLocaleString('id-ID') : '0'}
│ 🤖 Robo: ${user.robo > 0 ? 'Level ' + user.robo : '✖️'}
│ 🪙 BTC: ${user.btc ? user.btc.toFixed(8) : '0'}
│ 💴 LTC: ${user.ltc ? user.ltc.toLocaleString('id-ID') : '0'}
│ 💷 ETH: ${user.eth ? user.eth.toLocaleString('id-ID') : '0'}
│ 🏆 Emas: ${user.emas ? user.emas.toLocaleString('id-ID') : '0'}
│ 🌟 Status: ${who.split`@`[0] == info.nomorown ? 'Developer' : user.premiumTime >= 1 ? 'Pengguna Premium' : user.level >= 1000 ? 'Pengguna Elite' : 'Pengguna Biasa'}
│ 📑 Terdaftar: ${user.registered ? 'Ya' : 'Tidak'}
└────···
`.trim();

    await conn.adReply(m.chat, caption, '', '', fs.readFileSync('./media/bank.jpg'), '', m);
};

handler.help = ['bank 𝐅𝐢𝐱𝐞𝐝'];
handler.tags = ['rpg'];
handler.command = /^bank$/i;

handler.register = true;
handler.group = true;
handler.rpg = true;

export default handler;