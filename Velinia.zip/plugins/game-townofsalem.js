
class TownOfSalemGame {
  constructor(sendPrivateMessage, sendGroupMessage) {
    this.sendPrivateMessage = sendPrivateMessage;
    this.sendGroupMessage = sendGroupMessage;
    this.players = [];
    this.roles = {};
    this.deadPlayers = [];
    this.jailedPlayers = [];
    this.votingResults = {};
    this.gameState = 'lobby';
    this.discussionTimer = null;
    this.voteTimer = null;
  }

  addPlayer(player) {
    if (this.players.length < 10 && !this.players.includes(player)) {
      this.players.push(player);
      return true;
    }
    return false;
  }

  assignRoles() {
    if (this.players.length < 4) return; // Minimal 4 pemain untuk memulai

    const rolesList = ['Mafia', 'Investigator', 'Jailer', 'Doctor', 'Vigilante'];
    const shuffledPlayers = this.players.sort(() => Math.random() - 0.5);
    this.roles = shuffledPlayers.reduce((acc, player, index) => {
      const role = rolesList[index % rolesList.length] || 'Citizen';
      acc[player] = role;
      this.sendPrivateMessage(player, this.formatRoleMessage(role));
      return acc;
    }, {});
  }

  formatRoleMessage(role) {
    switch (role) {
      case 'Mafia':
        return `🕴️ *Peran Anda: Mafia*\n\nTugas Anda adalah membunuh semua Warga Desa tanpa ketahuan! Untuk membunuh, gunakan perintah "!town ability kill [target]".`;
      case 'Investigator':
        return `🕵️‍♂️ *Peran Anda: Investigator*\n\nAnda dapat menyelidiki peran pemain lain. Gunakan perintah "!town ability investigate [target]" untuk mengetahui peran target.`;
      case 'Jailer':
        return `🔒 *Peran Anda: Jailer*\n\nAnda dapat memenjarakan pemain lain. Gunakan perintah "!town ability jail [target]" untuk memenjarakan target.`;
      case 'Doctor':
        return `🩺 *Peran Anda: Doctor*\n\nAnda dapat menyembuhkan pemain lain. Gunakan perintah "!town ability heal [target]" untuk menyembuhkan target.`;
      case 'Vigilante':
        return `🔫 *Peran Anda: Vigilante*\n\nAnda dapat menembak pemain lain. Gunakan perintah "!town ability shoot [target]" untuk menembak target.`;
      case 'Citizen':
        return `👨‍💼 *Peran Anda: Warga Desa*\n\nTugas Anda adalah mengidentifikasi Mafia. Laporkan pemain yang mencurigakan dengan perintah "!town report [target]".`;
      default:
        return `*Peran Anda: ${role}*`;
    }
  }

  useAbility(user, target, ability) {
    if (this.gameState !== 'playing') {
      this.sendPrivateMessage(user, '*Tidak ada yang bisa dilakukan saat ini.*');
      return;
    }

    if (this.jailedPlayers.includes(user)) {
      this.sendPrivateMessage(user, '*Anda sedang dipenjara dan tidak dapat menggunakan kemampuan.*');
      return;
    }

    switch (ability) {
      case 'investigate':
        if (this.roles[user] === 'Investigator') {
          const role = this.roles[target];
          this.sendPrivateMessage(user, `*Investigasi: ${target} adalah ${role}.*`);
        } else {
          this.sendPrivateMessage(user, '*Anda bukan Investigator.*');
        }
        break;
      case 'jail':
        if (this.roles[user] === 'Jailer') {
          if (!this.deadPlayers.includes(target)) {
            this.jailedPlayers.push(target);
            this.sendPrivateMessage(target, `*Anda telah dipenjara oleh ${user}.*`);
            this.sendGroupMessage(`*${target} telah dipenjara oleh Jailer!*`);
          } else {
            this.sendPrivateMessage(user, `*${target} sudah mati dan tidak dapat dipenjara.*`);
          }
        } else {
          this.sendPrivateMessage(user, '*Anda bukan Jailer.*');
        }
        break;
      case 'heal':
        if (this.roles[user] === 'Doctor') {
          if (this.deadPlayers.includes(target)) {
            this.sendPrivateMessage(user, `*${target} sudah mati dan tidak dapat disembuhkan.*`);
          } else {
            this.sendPrivateMessage(target, `*Anda telah disembuhkan oleh ${user}.*`);
            this.sendGroupMessage(`*${target} telah disembuhkan oleh Doctor!*`);
          }
        } else {
          this.sendPrivateMessage(user, '*Anda bukan Doctor.*');
        }
        break;
      case 'shoot':
        if (this.roles[user] === 'Vigilante') {
          if (!this.deadPlayers.includes(target)) {
            this.deadPlayers.push(target);
            this.sendPrivateMessage(user, `*Anda menembak ${target}.*`);
            this.sendPrivateMessage(target, '*Anda telah ditembak oleh Vigilante!*');
            this.sendGroupMessage(`😱 *${target} telah ditembak oleh Vigilante!*`);
          } else {
            this.sendPrivateMessage(user, `*${target} sudah mati dan tidak dapat ditembak.*`);
          }
        } else {
          this.sendPrivateMessage(user, '*Anda bukan Vigilante.*');
        }
        break;
      case 'kill':
        if (this.roles[user] === 'Mafia') {
          if (!this.deadPlayers.includes(target) && !this.jailedPlayers.includes(target)) {
            this.deadPlayers.push(target);
            this.sendPrivateMessage(user, `*Anda membunuh ${target}.*`);
            this.sendPrivateMessage(target, '*Anda telah dibunuh oleh Mafia!*');
            this.sendGroupMessage(`😱 *${target} telah dibunuh oleh Mafia!*`);
          } else {
            this.sendPrivateMessage(user, `*${target} sudah mati atau dipenjara dan tidak dapat dibunuh.*`);
          }
        } else {
          this.sendPrivateMessage(user, '*Anda bukan Mafia.*');
        }
        break;
      default:
        this.sendPrivateMessage(user, '*Kemampuan tidak valid.*');
    }
  }

  startGame() {
    this.assignRoles();
    this.gameState = 'playing';
    this.sendGroupMessage(`🚀 *Town of Salem dimulai!* \n\n${this.players.join(', ')} siap untuk memulai permainan.`);
    this.startDiscussionTimer();
  }

  startDiscussionTimer() {
    this.gameState = 'discussion';
    let timer = 120; // 2 menit
    this.discussionTimer = setInterval(() => {
      timer--;
      if (timer === 0) {
        clearInterval(this.discussionTimer);
        this.startVoting();
      }
    }, 1000);
  }

  startVoting() {
    this.gameState = 'voting';
    let timer = 60; // 1 menit
    this.voteTimer = setInterval(() => {
      timer--;
      if (timer === 0) {
        clearInterval(this.voteTimer);
        this.tallyVotes();
      }
    }, 1000);
  }

  tallyVotes() {
    const voteCount = Object.values(this.votingResults).reduce((a, b) => (a || 0) + b, 0);
    if (voteCount === 0) {
      this.sendGroupMessage('*Tidak ada yang terpilih.*');
    } else {
      const mostVotedPlayer = Object.keys(this.votingResults).reduce((a, b) => this.votingResults[a] > this.votingResults[b] ? a : b);
      if (this.roles[mostVotedPlayer] === 'Mafia') {
        this.sendGroupMessage(`*${mostVotedPlayer} adalah Mafia!* Warga Desa menang!`);
        this.winCitizens();
      } else {
        this.sendGroupMessage(`*${mostVotedPlayer} terpilih.* Mafia menang!`);
        this.winMafia();
      }
    }
    this.resetVoting();
  }

  resetVoting() {
    this.votingResults = {};
    this.gameState = 'playing';
  }

  winCitizens() {
    this.sendGroupMessage('*Warga Desa menang!*');
    this.resetGame();
  }

  winMafia() {
    this.sendGroupMessage('*Mafia menang!*');
    this.resetGame();
  }

  resetGame() {
    this.players = [];
    this.roles = {};
    this.deadPlayers = [];
    this.jailedPlayers = [];
    this.votingResults = {};
    this.gameState = 'lobby';
    clearInterval(this.discussionTimer);
    clearInterval(this.voteTimer);
  }

  vote(voter, votedPlayer) {
    if (this.gameState === 'voting') {
      this.votingResults[votedPlayer] = (this.votingResults[votedPlayer] || 0) + 1;
      this.sendGroupMessage(`*${voter} memilih ${votedPlayer}.*`);
    } else {
      this.sendPrivateMessage(voter, '*Tidak ada sesi voting yang sedang berlangsung.*');
    }
  }

  report(reporter, reported) {
    if (this.gameState === 'playing') {
      if (this.deadPlayers.includes(reported)) {
        this.sendPrivateMessage(reporter, `*${reported} sudah mati.*`);
      } else {
        this.deadPlayers.push(reported);
        const message = `😱 *${reporter} menemukan mayat ${reported}!*`;
        this.sendGroupMessage(message);
        this.startDiscussionTimer();
      }
    } else {
      this.sendPrivateMessage(reporter, `*Tidak ada yang bisa dilaporkan saat ini.* Permainan sedang dalam fase ${this.gameState}.`);
    }
  }
}

const handler = async (m, { conn, args, usedPrefix, command }) => {
  conn.town_of_salem = conn.town_of_salem || {};
  const sessions = conn.town_of_salem_ = conn.town_of_salem_ || {};
  const sessionId = m.chat;
  const session = sessions[sessionId] || (sessions[sessionId] = new TownOfSalemGame(
    conn.sendMessage.bind(conn, m.sender),
    conn.sendMessage.bind(conn)
  ));
  const game = session;

  switch (args[0]) {
    case 'join':
      if (game.gameState !== 'lobby') return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat bergabung.');
      const playerName = m.sender;
      const joinSuccess = game.addPlayer(playerName);
      joinSuccess ? m.reply(`👋 *${playerName} bergabung ke dalam permainan.*`) : m.reply('*Anda sudah bergabung atau permainan sudah penuh.* Tidak dapat bergabung.');
      break;

    case 'start':
      if (game.gameState !== 'lobby') return m.reply('🛑 *Permainan sudah dimulai.* Tidak dapat memulai ulang.');
      if (game.players.length >= 4) {
        game.startGame();
      } else {
        await m.reply('👥 *Tidak cukup pemain untuk memulai permainan.* Diperlukan minimal 4 pemain.');
      }
      break;

    case 'report':
      if (game.gameState !== 'playing') return m.reply('🛑 *Permainan belum dimulai.* Ketik "!town start" untuk memulai.');
      const [reported] = args.slice(1);
      game.report(m.sender, reported);
      break;

    case 'vote':
      if (game.gameState !== 'voting') return m.reply('🛑 *Belum saatnya voting.*');
      const [votedPlayer] = args.slice(1);
      game.vote(m.sender, votedPlayer);
      break;

    case 'ability':
      if (game.gameState !== 'playing') return m.reply('🛑 *Permainan belum dimulai.* Ketik "!town start" untuk memulai.');
      const [ability, target] = args.slice(1);
      game.useAbility(m.sender, target, ability);
      break;

    case 'reset':
      game.resetGame();
      delete sessions[sessionId];
      await m.reply('🔄 *Sesi permainan direset.*');
      break;

    case 'help':
      await m.reply(`🚀 *Town of Salem* 🚀

Town of Salem adalah permainan multiplayer online di mana beberapa pemain ditunjuk sebagai "Mafia", sementara yang lain menjadi "Warga Desa". Tujuan Mafia adalah membunuh semua Warga Desa tanpa ketahuan, sementara Warga Desa harus mengidentifikasi Mafia dan memenangkan permainan.

*🎮 Cara Bermain:*
1. Permainan dimainkan oleh 4-10 pemain.
2. Beberapa pemain akan ditunjuk sebagai Mafia, sementara yang lain memiliki peran lain seperti Investigator, Jailer, Doctor, atau Warga Desa biasa.
3. Mafia berusaha membunuh Warga Desa tanpa ketahuan.
4. Warga Desa harus mengidentifikasi Mafia dan melakukan voting untuk memenangkan permainan.
5. Pemain dengan peran khusus (Investigator, Jailer, Doctor, Vigilante) dapat menggunakan kemampuan mereka untuk membantu Warga Desa.
6. Jika Mafia terpilih, Warga Desa menang. Jika tidak, Mafia menang.

*👥 Jumlah Pemain:*
- Town of Salem dapat dimainkan oleh 4 hingga 10 pemain.

*🛠️ Perintah Permainan:*
• ${usedPrefix + command} join  : Bergabung ke dalam permainan
• ${usedPrefix + command} start : Memulai permainan
• ${usedPrefix + command} report [player] : Melaporkan pemain yang ditemukan mati
• ${usedPrefix + command} vote [player] : Memilih pemain yang dicurigai sebagai Mafia
• ${usedPrefix + command} ability [ability] [target] : Menggunakan kemampuan khusus (investigasi, penjara, penyembuhan, penembakan)
• ${usedPrefix + command} reset : Mengatur ulang sesi permainan

*💡 Tips Bermain:*
- Sebagai Mafia, bersikaplah natural dan hindari kecurigaan.
- Sebagai Warga Desa, perhatikan perilaku pemain lain dan laporkan hal yang mencurigakan.
- Diskusikan dan gunakan suara mayoritas untuk memilih Mafia.
- Pemain dengan peran khusus harus menggunakan kemampuan mereka dengan bijak.
- Kerja sama tim adalah kunci dalam memenangkan Town of Salem!

Selamat bermain dan semoga keberuntungan berpihak pada Anda! 🍀`);
      break;

    default:
      m.reply(`❓ *Perintah tidak valid.* Gunakan ${usedPrefix + command} help untuk melihat daftar perintah.`);
  }
};

handler.help = ['town 𝐁𝐚𝐫𝐮+𝐁𝐞𝐭𝐚'];
handler.tags = ['game'];
handler.command = /^(townofsalem|town)$/i;
handler.group = true;

export default handler;