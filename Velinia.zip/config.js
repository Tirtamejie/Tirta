/* JANGAN HAPUS INI 
SCRIPT BY © crack ip
•• recode kasih credits 
•• contacts: (6282389924037)
•• instagram: @mega crack
•• (github.com/mega crack) 
*/
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
/*=========== LINK ============*/
global.link = {
	ig: 'https://instagram.com/tirtamejiy',
	gh: 'https://github.com/tirtamejie',
	gc: 'https://chat.whatsapp.com/Ie28t9Cz5Z6AQMwN6fr2yV',
	web: 'https://linkbio.co/6101315UUcgsS',
	yt: 'https://youtube.com/@tirtamejie',
	fb: 'https://m.facebook.com/lanmaksleo',
    tree: 'https://linkbio.co/6101315UUcgsS',
	nh: 'https://nhentai.net/g/365296/'	
}
/*===========PAYMENT==========*/
/*============DONASI===========*/
global.pay = {
	dana: '083838348918',
	ovo: '083838348918',
	gopay: '083838348918',
	pulsa: '083838348918',
	qris: 'https://files.catbox.moe/ne544i.jpg'
}
/*==============================*/
/*========= NOMOR ============*/
global.info = {
	nomorbot: '6283838348918',
	nomorown: '6283152618677',
	namebot: '© 𝐓𝐢𝐧𝐳𝐁𝐨𝐭𝐳',
	nameown: 'TirtaMejie'
}
/*==============================*/
/*=========== STAFF ============*/
global.owner = [
    ['6283152618677', 'Crack', 'true'],
    ['6283152618677', 'Crack', 'true']
]
global.mods = [] 
global.prems = [] 
/*==============================*/
/*=========== GlobalAPI ============*/
global.zein = 'zenzkey_848b800b1f'
global.skizo = 'sweattheartkyl'
global.rose = 'Rk-Ashbornt'
global.lol = 'Faykaloffc'
global.neoxr = 'Sanzxdid'
global.can = 'ItsukaChan'
global.btc = 'Rizalzllk'
/*==============================*/
/*==============API ==============*/
global.APIs = {
    // API Prefix
    // name: 'https://website'
    xteam: 'https://api.xteam.xyz',
    lol: 'https://api.lolhuman.xyz',
    males: 'https://malesin.xyz',
    zein: 'https://api.zahwazein.xyz',
    rose: 'https://api.itsrose.life',
    skizo: 'https://skizo.tech',
    saipul: 'https://saipulanuar.cf'
}
global.APIKeys = {
    // APIKey Here
    // 'https://website': 'apikey'
    'https://api.zahwazein.xyz': 'zenzkey_848b800b1f',
    'https://api.xteam.xyz': 'cristian9407',
    'https://api.lolhuman.xyz': 'Faykaloffc',
    'https://api.itsrose.life': 'Rk-Ashbornt',
    'https://skizo.tech' : 'sweattheartkyl'
}
/*==============================*/
/*======== WATERMARK ========*/
global.versibot = '10.18'
global.wm = '© 2024 Crack' 
global.author = 'Crack'
global.wait = '_「P R O C E S S 」_'
/*==============================*/
global.fsizedoc = '99999999999999'
global.fpagedoc = '999'
global.maxwarn = 5;
/*======= TYPE DOCUMENT ======*/
global.doc = {
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    pdf: 'application/pdf',
    rtf: 'text/rtf'
}
/*==============================*/
/*========== HIASAN ===========*/
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}
/*=========== FOTO ============*/
global.elainajpg = [
    'https://telegra.ph/file/3e43fcfaea6dc1ba95617.jpg',
    'https://telegra.ph/file/c738a9fc0722a59825cbb.mp4',
    'https://telegra.ph/file/4018167852aef19651f46.jpg',]
global.vynaajpg = 'https://files.catbox.moe/f5ppet.jpg',    
// INI THUMBNAIL 
global.thumbnail = 'https://telegra.ph/file/57699ca7b3d8b93885594.jpg',    
/*==============================*/
/*==============================*/
// WELCOME GOOD BYE 
global.wel = 'https://telegra.ph/file/ddc2589307fe851dfa1db.mp4',
global.good = 'https://telegra.ph/file/b262558cf65343c584e64.mp4',
/*==============================*/
/*==============================*/
global.flaaa = [
    'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',
    'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text='
]
global.hwaifu = [
    'https://i.pinimg.com/originals/ed/34/f8/ed34f88af161e6278993e1598c29a621.jpg',
    'https://i.pinimg.com/originals/85/4d/bb/854dbbd30304cd69f305352f0183fad0.jpg',
]

/*==================================*/
/*======== STICKER WM ============*/
global.stickpack = 'Rory mercury'
global.stickauth = '© Rory mercury'

global.multiplier = 38 // The higher, The harder levelup
/*===================================*/
/*============== EMOJI ==============*/
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'config.js'"))
    import(`${file}?update=${Date.now()}`)
})
